package newbuildorder.util;

import battlecode.common.Direction;
import battlecode.common.GameActionException;
import battlecode.common.MapLocation;

import static newbuildorder.util.Constants.rc;

public class Generated9 {
    public static Direction ret;

    public static void debug_execute(MapLocation target) throws GameActionException {
        ret = execute(target);
    }
    public static double dp_2_1;
    public static Direction dir_2_1;
    public static double rubble_2_1;
    public static boolean onTheMap_2_1;
    public static MapLocation loc_2_1;
    public static double dp_1_1;
    public static Direction dir_1_1;
    public static double rubble_1_1;
    public static boolean onTheMap_1_1;
    public static MapLocation loc_1_1;
    public static double dp_2_2;
    public static Direction dir_2_2;
    public static double rubble_2_2;
    public static boolean onTheMap_2_2;
    public static MapLocation loc_2_2;
    public static double dp_1_2;
    public static Direction dir_1_2;
    public static double rubble_1_2;
    public static boolean onTheMap_1_2;
    public static MapLocation loc_1_2;
    public static double dp_0_3;
    public static Direction dir_0_3;
    public static double rubble_0_3;
    public static boolean onTheMap_0_3;
    public static MapLocation loc_0_3;
    public static double dp_1_3;
    public static Direction dir_1_3;
    public static double rubble_1_3;
    public static boolean onTheMap_1_3;
    public static MapLocation loc_1_3;
    public static double dp_2_3;
    public static Direction dir_2_3;
    public static double rubble_2_3;
    public static boolean onTheMap_2_3;
    public static MapLocation loc_2_3;
    public static double dp_1_4;
    public static Direction dir_1_4;
    public static double rubble_1_4;
    public static boolean onTheMap_1_4;
    public static MapLocation loc_1_4;
    public static double dp_2_4;
    public static Direction dir_2_4;
    public static double rubble_2_4;
    public static boolean onTheMap_2_4;
    public static MapLocation loc_2_4;
    public static double dp_1_5;
    public static Direction dir_1_5;
    public static double rubble_1_5;
    public static boolean onTheMap_1_5;
    public static MapLocation loc_1_5;
    public static double dp_2_5;
    public static Direction dir_2_5;
    public static double rubble_2_5;
    public static boolean onTheMap_2_5;
    public static MapLocation loc_2_5;
    public static double dp_3_3;
    public static Direction dir_3_3;
    public static double rubble_3_3;
    public static boolean onTheMap_3_3;
    public static MapLocation ourLocation;
    public static double dp_3_4;
    public static Direction dir_3_4;
    public static double rubble_3_4;
    public static boolean onTheMap_3_4;
    public static MapLocation loc_3_4;
    public static double dp_3_5;
    public static Direction dir_3_5;
    public static double rubble_3_5;
    public static boolean onTheMap_3_5;
    public static MapLocation loc_3_5;
    public static double dp_3_6;
    public static Direction dir_3_6;
    public static double rubble_3_6;
    public static boolean onTheMap_3_6;
    public static MapLocation loc_3_6;
    public static double dp_4_5;
    public static Direction dir_4_5;
    public static double rubble_4_5;
    public static boolean onTheMap_4_5;
    public static MapLocation loc_4_5;
    public static double dp_4_4;
    public static Direction dir_4_4;
    public static double rubble_4_4;
    public static boolean onTheMap_4_4;
    public static MapLocation loc_4_4;
    public static double dp_5_5;
    public static Direction dir_5_5;
    public static double rubble_5_5;
    public static boolean onTheMap_5_5;
    public static MapLocation loc_5_5;
    public static double dp_5_4;
    public static Direction dir_5_4;
    public static double rubble_5_4;
    public static boolean onTheMap_5_4;
    public static MapLocation loc_5_4;
    public static double dp_4_3;
    public static Direction dir_4_3;
    public static double rubble_4_3;
    public static boolean onTheMap_4_3;
    public static MapLocation loc_4_3;
    public static double dp_5_3;
    public static Direction dir_5_3;
    public static double rubble_5_3;
    public static boolean onTheMap_5_3;
    public static MapLocation loc_5_3;
    public static double dp_6_3;
    public static Direction dir_6_3;
    public static double rubble_6_3;
    public static boolean onTheMap_6_3;
    public static MapLocation loc_6_3;
    public static double dp_5_2;
    public static Direction dir_5_2;
    public static double rubble_5_2;
    public static boolean onTheMap_5_2;
    public static MapLocation loc_5_2;
    public static double dp_5_1;
    public static Direction dir_5_1;
    public static double rubble_5_1;
    public static boolean onTheMap_5_1;
    public static MapLocation loc_5_1;
    public static double dp_4_2;
    public static Direction dir_4_2;
    public static double rubble_4_2;
    public static boolean onTheMap_4_2;
    public static MapLocation loc_4_2;
    public static double dp_4_1;
    public static Direction dir_4_1;
    public static double rubble_4_1;
    public static boolean onTheMap_4_1;
    public static MapLocation loc_4_1;
    public static double dp_3_0;
    public static Direction dir_3_0;
    public static double rubble_3_0;
    public static boolean onTheMap_3_0;
    public static MapLocation loc_3_0;
    public static double dp_3_1;
    public static Direction dir_3_1;
    public static double rubble_3_1;
    public static boolean onTheMap_3_1;
    public static MapLocation loc_3_1;
    public static double dp_3_2;
    public static Direction dir_3_2;
    public static double rubble_3_2;
    public static boolean onTheMap_3_2;
    public static MapLocation loc_3_2;
    public static Direction execute(MapLocation target) throws GameActionException {
        ourLocation = rc.getLocation();
        if(ourLocation.equals(target)) {
            return Direction.CENTER;
        }
        int ourLocationX = ourLocation.x;
        int ourLocationY = ourLocation.y;
        loc_2_3 = rc.adjacentLocation(Direction.SOUTH);
        loc_4_3 = rc.adjacentLocation(Direction.NORTH);
        loc_1_3 = loc_2_3.add(Direction.SOUTH);
        loc_5_3 = loc_4_3.add(Direction.NORTH);
        loc_0_3 = loc_1_3.add(Direction.SOUTH);
        loc_6_3 = loc_5_3.add(Direction.NORTH);
        loc_3_4 = rc.adjacentLocation(Direction.EAST);
        loc_3_2 = rc.adjacentLocation(Direction.WEST);
        loc_2_2 = rc.adjacentLocation(Direction.SOUTHWEST);
        loc_2_4 = rc.adjacentLocation(Direction.SOUTHEAST);
        loc_4_4 = rc.adjacentLocation(Direction.NORTHEAST);
        loc_4_2 = rc.adjacentLocation(Direction.NORTHWEST);
        loc_1_2 = loc_1_3.add(Direction.WEST);
        loc_1_4 = loc_1_3.add(Direction.EAST);
        loc_5_4 = loc_5_3.add(Direction.EAST);
        loc_5_2 = loc_5_3.add(Direction.WEST);
        loc_3_5 = loc_3_4.add(Direction.EAST);
        loc_3_1 = loc_3_2.add(Direction.WEST);
        loc_2_1 = loc_2_2.add(Direction.WEST);
        loc_2_5 = loc_2_4.add(Direction.EAST);
        loc_4_5 = loc_4_4.add(Direction.EAST);
        loc_4_1 = loc_4_2.add(Direction.WEST);
        loc_1_1 = loc_1_2.add(Direction.WEST);
        loc_1_5 = loc_1_4.add(Direction.EAST);
        loc_5_5 = loc_5_4.add(Direction.EAST);
        loc_5_1 = loc_5_2.add(Direction.WEST);
        loc_3_6 = loc_3_5.add(Direction.EAST);
        loc_3_0 = loc_3_1.add(Direction.WEST);
        dp_2_1 = Double.MAX_VALUE;
        onTheMap_2_1 = rc.onTheMap(loc_2_1);
        if (onTheMap_2_1) {
            rubble_2_1 = 1.0 + rc.senseRubble(loc_2_1) / 10.0;
        }
        dp_1_1 = Double.MAX_VALUE;
        onTheMap_1_1 = rc.onTheMap(loc_1_1);
        if (onTheMap_1_1) {
            rubble_1_1 = 1.0 + rc.senseRubble(loc_1_1) / 10.0;
        }
        dp_2_2 = Double.MAX_VALUE;
        onTheMap_2_2 = rc.onTheMap(loc_2_2);
        if (onTheMap_2_2) {
            rubble_2_2 = 1.0 + rc.senseRubble(loc_2_2) / 10.0;
        }
        dp_1_2 = Double.MAX_VALUE;
        onTheMap_1_2 = rc.onTheMap(loc_1_2);
        if (onTheMap_1_2) {
            rubble_1_2 = 1.0 + rc.senseRubble(loc_1_2) / 10.0;
        }
        dp_0_3 = Double.MAX_VALUE;
        onTheMap_0_3 = rc.onTheMap(loc_0_3);
        if (onTheMap_0_3) {
            rubble_0_3 = 1.0 + rc.senseRubble(loc_0_3) / 10.0;
        }
        dp_1_3 = Double.MAX_VALUE;
        onTheMap_1_3 = rc.onTheMap(loc_1_3);
        if (onTheMap_1_3) {
            rubble_1_3 = 1.0 + rc.senseRubble(loc_1_3) / 10.0;
        }
        dp_2_3 = Double.MAX_VALUE;
        onTheMap_2_3 = rc.onTheMap(loc_2_3);
        if (onTheMap_2_3) {
            rubble_2_3 = 1.0 + rc.senseRubble(loc_2_3) / 10.0;
        }
        dp_1_4 = Double.MAX_VALUE;
        onTheMap_1_4 = rc.onTheMap(loc_1_4);
        if (onTheMap_1_4) {
            rubble_1_4 = 1.0 + rc.senseRubble(loc_1_4) / 10.0;
        }
        dp_2_4 = Double.MAX_VALUE;
        onTheMap_2_4 = rc.onTheMap(loc_2_4);
        if (onTheMap_2_4) {
            rubble_2_4 = 1.0 + rc.senseRubble(loc_2_4) / 10.0;
        }
        dp_1_5 = Double.MAX_VALUE;
        onTheMap_1_5 = rc.onTheMap(loc_1_5);
        if (onTheMap_1_5) {
            rubble_1_5 = 1.0 + rc.senseRubble(loc_1_5) / 10.0;
        }
        dp_2_5 = Double.MAX_VALUE;
        onTheMap_2_5 = rc.onTheMap(loc_2_5);
        if (onTheMap_2_5) {
            rubble_2_5 = 1.0 + rc.senseRubble(loc_2_5) / 10.0;
        }
        dp_3_3 = 0;
        onTheMap_3_3 = rc.onTheMap(ourLocation);
        if (onTheMap_3_3) {
            rubble_3_3 = 1.0 + rc.senseRubble(ourLocation) / 10.0;
        }
        dp_3_4 = Double.MAX_VALUE;
        onTheMap_3_4 = rc.onTheMap(loc_3_4);
        if (onTheMap_3_4) {
            rubble_3_4 = 1.0 + rc.senseRubble(loc_3_4) / 10.0;
        }
        dp_3_5 = Double.MAX_VALUE;
        onTheMap_3_5 = rc.onTheMap(loc_3_5);
        if (onTheMap_3_5) {
            rubble_3_5 = 1.0 + rc.senseRubble(loc_3_5) / 10.0;
        }
        dp_3_6 = Double.MAX_VALUE;
        onTheMap_3_6 = rc.onTheMap(loc_3_6);
        if (onTheMap_3_6) {
            rubble_3_6 = 1.0 + rc.senseRubble(loc_3_6) / 10.0;
        }
        dp_4_5 = Double.MAX_VALUE;
        onTheMap_4_5 = rc.onTheMap(loc_4_5);
        if (onTheMap_4_5) {
            rubble_4_5 = 1.0 + rc.senseRubble(loc_4_5) / 10.0;
        }
        dp_4_4 = Double.MAX_VALUE;
        onTheMap_4_4 = rc.onTheMap(loc_4_4);
        if (onTheMap_4_4) {
            rubble_4_4 = 1.0 + rc.senseRubble(loc_4_4) / 10.0;
        }
        dp_5_5 = Double.MAX_VALUE;
        onTheMap_5_5 = rc.onTheMap(loc_5_5);
        if (onTheMap_5_5) {
            rubble_5_5 = 1.0 + rc.senseRubble(loc_5_5) / 10.0;
        }
        dp_5_4 = Double.MAX_VALUE;
        onTheMap_5_4 = rc.onTheMap(loc_5_4);
        if (onTheMap_5_4) {
            rubble_5_4 = 1.0 + rc.senseRubble(loc_5_4) / 10.0;
        }
        dp_4_3 = Double.MAX_VALUE;
        onTheMap_4_3 = rc.onTheMap(loc_4_3);
        if (onTheMap_4_3) {
            rubble_4_3 = 1.0 + rc.senseRubble(loc_4_3) / 10.0;
        }
        dp_5_3 = Double.MAX_VALUE;
        onTheMap_5_3 = rc.onTheMap(loc_5_3);
        if (onTheMap_5_3) {
            rubble_5_3 = 1.0 + rc.senseRubble(loc_5_3) / 10.0;
        }
        dp_6_3 = Double.MAX_VALUE;
        onTheMap_6_3 = rc.onTheMap(loc_6_3);
        if (onTheMap_6_3) {
            rubble_6_3 = 1.0 + rc.senseRubble(loc_6_3) / 10.0;
        }
        dp_5_2 = Double.MAX_VALUE;
        onTheMap_5_2 = rc.onTheMap(loc_5_2);
        if (onTheMap_5_2) {
            rubble_5_2 = 1.0 + rc.senseRubble(loc_5_2) / 10.0;
        }
        dp_5_1 = Double.MAX_VALUE;
        onTheMap_5_1 = rc.onTheMap(loc_5_1);
        if (onTheMap_5_1) {
            rubble_5_1 = 1.0 + rc.senseRubble(loc_5_1) / 10.0;
        }
        dp_4_2 = Double.MAX_VALUE;
        onTheMap_4_2 = rc.onTheMap(loc_4_2);
        if (onTheMap_4_2) {
            rubble_4_2 = 1.0 + rc.senseRubble(loc_4_2) / 10.0;
        }
        dp_4_1 = Double.MAX_VALUE;
        onTheMap_4_1 = rc.onTheMap(loc_4_1);
        if (onTheMap_4_1) {
            rubble_4_1 = 1.0 + rc.senseRubble(loc_4_1) / 10.0;
        }
        dp_3_0 = Double.MAX_VALUE;
        onTheMap_3_0 = rc.onTheMap(loc_3_0);
        if (onTheMap_3_0) {
            rubble_3_0 = 1.0 + rc.senseRubble(loc_3_0) / 10.0;
        }
        dp_3_1 = Double.MAX_VALUE;
        onTheMap_3_1 = rc.onTheMap(loc_3_1);
        if (onTheMap_3_1) {
            rubble_3_1 = 1.0 + rc.senseRubble(loc_3_1) / 10.0;
        }
        dp_3_2 = Double.MAX_VALUE;
        onTheMap_3_2 = rc.onTheMap(loc_3_2);
        if (onTheMap_3_2) {
            rubble_3_2 = 1.0 + rc.senseRubble(loc_3_2) / 10.0;
        }
        if (rc.canMove(Direction.EAST)) {
            dp_3_4 = rubble_3_3;
            dir_3_4 = Direction.EAST;
        }
        if (rc.canMove(Direction.NORTH)) {
            dp_4_3 = rubble_3_3;
            dir_4_3 = Direction.NORTH;
        }
        if (rc.canMove(Direction.WEST)) {
            dp_3_2 = rubble_3_3;
            dir_3_2 = Direction.WEST;
        }
        if (rc.canMove(Direction.SOUTH)) {
            dp_2_3 = rubble_3_3;
            dir_2_3 = Direction.SOUTH;
        }
        if (rc.canMove(Direction.NORTHEAST)) {
            dp_4_4 = rubble_3_3;
            dir_4_4 = Direction.NORTHEAST;
        }
        if (rc.canMove(Direction.NORTHWEST)) {
            dp_4_2 = rubble_3_3;
            dir_4_2 = Direction.NORTHWEST;
        }
        if (rc.canMove(Direction.SOUTHWEST)) {
            dp_2_2 = rubble_3_3;
            dir_2_2 = Direction.SOUTHWEST;
        }
        if (rc.canMove(Direction.SOUTHEAST)) {
            dp_2_4 = rubble_3_3;
            dir_2_4 = Direction.SOUTHEAST;
        }
        double next_3_2 = dp_2_3 + rubble_2_3;
        if (onTheMap_1_3) {
            dp_1_3 = next_3_2;
            dir_1_3 = dir_2_3;
        }
        if (onTheMap_1_2) {
            dp_1_2 = next_3_2;
            dir_1_2 = dir_2_3;
        }
        if (onTheMap_1_4) {
            dp_1_4 = next_3_2;
            dir_1_4 = dir_2_3;
        }
        double next_4_3 = dp_3_4 + rubble_3_4;
        if (onTheMap_3_5) {
            dp_3_5 = next_4_3;
            dir_3_5 = dir_3_4;
        }
        if (onTheMap_4_5) {
            dp_4_5 = next_4_3;
            dir_4_5 = dir_3_4;
        }
        if (onTheMap_2_5) {
            dp_2_5 = next_4_3;
            dir_2_5 = dir_3_4;
        }
        double next_3_4 = dp_4_3 + rubble_4_3;
        if (onTheMap_5_3) {
            dp_5_3 = next_3_4;
            dir_5_3 = dir_4_3;
        }
        if (onTheMap_5_4) {
            dp_5_4 = next_3_4;
            dir_5_4 = dir_4_3;
        }
        if (onTheMap_5_2) {
            dp_5_2 = next_3_4;
            dir_5_2 = dir_4_3;
        }
        double next_2_3 = dp_3_2 + rubble_3_2;
        if (onTheMap_3_1) {
            dp_3_1 = next_2_3;
            dir_3_1 = dir_3_2;
        }
        if (onTheMap_4_1) {
            dp_4_1 = next_2_3;
            dir_4_1 = dir_3_2;
        }
        if (onTheMap_2_1) {
            dp_2_1 = next_2_3;
            dir_2_1 = dir_3_2;
        }
        double next_2_2 = dp_2_2 + rubble_2_2;
        if (onTheMap_2_1) {
            if (next_2_2 < dp_2_1) {
                dp_2_1 = next_2_2;
                dir_2_1 = dir_2_2;
            }
        }
        if (onTheMap_1_2) {
            if (next_2_2 < dp_1_2) {
                dp_1_2 = next_2_2;
                dir_1_2 = dir_2_2;
            }
        }
        if (onTheMap_3_1) {
            if (next_2_2 < dp_3_1) {
                dp_3_1 = next_2_2;
                dir_3_1 = dir_2_2;
            }
        }
        if (onTheMap_1_1) {
            dp_1_1 = next_2_2;
            dir_1_1 = dir_2_2;
        }
        if (onTheMap_1_3) {
            if (next_2_2 < dp_1_3) {
                dp_1_3 = next_2_2;
                dir_1_3 = dir_2_2;
            }
        }
        double next_4_2 = dp_2_4 + rubble_2_4;
        if (onTheMap_2_5) {
            if (next_4_2 < dp_2_5) {
                dp_2_5 = next_4_2;
                dir_2_5 = dir_2_4;
            }
        }
        if (onTheMap_1_4) {
            if (next_4_2 < dp_1_4) {
                dp_1_4 = next_4_2;
                dir_1_4 = dir_2_4;
            }
        }
        if (onTheMap_3_5) {
            if (next_4_2 < dp_3_5) {
                dp_3_5 = next_4_2;
                dir_3_5 = dir_2_4;
            }
        }
        if (onTheMap_1_3) {
            if (next_4_2 < dp_1_3) {
                dp_1_3 = next_4_2;
                dir_1_3 = dir_2_4;
            }
        }
        if (onTheMap_1_5) {
            dp_1_5 = next_4_2;
            dir_1_5 = dir_2_4;
        }
        double next_4_4 = dp_4_4 + rubble_4_4;
        if (onTheMap_4_5) {
            if (next_4_4 < dp_4_5) {
                dp_4_5 = next_4_4;
                dir_4_5 = dir_4_4;
            }
        }
        if (onTheMap_5_4) {
            if (next_4_4 < dp_5_4) {
                dp_5_4 = next_4_4;
                dir_5_4 = dir_4_4;
            }
        }
        if (onTheMap_5_5) {
            dp_5_5 = next_4_4;
            dir_5_5 = dir_4_4;
        }
        if (onTheMap_5_3) {
            if (next_4_4 < dp_5_3) {
                dp_5_3 = next_4_4;
                dir_5_3 = dir_4_4;
            }
        }
        if (onTheMap_3_5) {
            if (next_4_4 < dp_3_5) {
                dp_3_5 = next_4_4;
                dir_3_5 = dir_4_4;
            }
        }
        double next_2_4 = dp_4_2 + rubble_4_2;
        if (onTheMap_5_2) {
            if (next_2_4 < dp_5_2) {
                dp_5_2 = next_2_4;
                dir_5_2 = dir_4_2;
            }
        }
        if (onTheMap_4_1) {
            if (next_2_4 < dp_4_1) {
                dp_4_1 = next_2_4;
                dir_4_1 = dir_4_2;
            }
        }
        if (onTheMap_5_3) {
            if (next_2_4 < dp_5_3) {
                dp_5_3 = next_2_4;
                dir_5_3 = dir_4_2;
            }
        }
        if (onTheMap_5_1) {
            dp_5_1 = next_2_4;
            dir_5_1 = dir_4_2;
        }
        if (onTheMap_3_1) {
            if (next_2_4 < dp_3_1) {
                dp_3_1 = next_2_4;
                dir_3_1 = dir_4_2;
            }
        }
        double next_3_1 = dp_1_3 + rubble_1_3;
        if (onTheMap_1_4) {
            if (next_3_1 < dp_1_4) {
                dp_1_4 = next_3_1;
                dir_1_4 = dir_1_3;
            }
        }
        if (onTheMap_1_2) {
            if (next_3_1 < dp_1_2) {
                dp_1_2 = next_3_1;
                dir_1_2 = dir_1_3;
            }
        }
        if (onTheMap_0_3) {
            dp_0_3 = next_3_1;
            dir_0_3 = dir_1_3;
        }
        double next_5_3 = dp_3_5 + rubble_3_5;
        if (onTheMap_3_6) {
            dp_3_6 = next_5_3;
            dir_3_6 = dir_3_5;
        }
        if (onTheMap_4_5) {
            if (next_5_3 < dp_4_5) {
                dp_4_5 = next_5_3;
                dir_4_5 = dir_3_5;
            }
        }
        if (onTheMap_2_5) {
            if (next_5_3 < dp_2_5) {
                dp_2_5 = next_5_3;
                dir_2_5 = dir_3_5;
            }
        }
        double next_3_5 = dp_5_3 + rubble_5_3;
        if (onTheMap_5_4) {
            if (next_3_5 < dp_5_4) {
                dp_5_4 = next_3_5;
                dir_5_4 = dir_5_3;
            }
        }
        if (onTheMap_6_3) {
            dp_6_3 = next_3_5;
            dir_6_3 = dir_5_3;
        }
        if (onTheMap_5_2) {
            if (next_3_5 < dp_5_2) {
                dp_5_2 = next_3_5;
                dir_5_2 = dir_5_3;
            }
        }
        double next_1_3 = dp_3_1 + rubble_3_1;
        if (onTheMap_4_1) {
            if (next_1_3 < dp_4_1) {
                dp_4_1 = next_1_3;
                dir_4_1 = dir_3_1;
            }
        }
        if (onTheMap_3_0) {
            dp_3_0 = next_1_3;
            dir_3_0 = dir_3_1;
        }
        if (onTheMap_2_1) {
            if (next_1_3 < dp_2_1) {
                dp_2_1 = next_1_3;
                dir_2_1 = dir_3_1;
            }
        }
        double next_1_2 = dp_2_1 + rubble_2_1;
        if (onTheMap_1_1) {
            if (next_1_2 < dp_1_1) {
                dp_1_1 = next_1_2;
                dir_1_1 = dir_2_1;
            }
        }
        if (onTheMap_3_0) {
            if (next_1_2 < dp_3_0) {
                dp_3_0 = next_1_2;
                dir_3_0 = dir_2_1;
            }
        }
        double next_2_1 = dp_1_2 + rubble_1_2;
        if (onTheMap_1_1) {
            if (next_2_1 < dp_1_1) {
                dp_1_1 = next_2_1;
                dir_1_1 = dir_1_2;
            }
        }
        if (onTheMap_0_3) {
            if (next_2_1 < dp_0_3) {
                dp_0_3 = next_2_1;
                dir_0_3 = dir_1_2;
            }
        }
        double next_4_1 = dp_1_4 + rubble_1_4;
        if (onTheMap_1_5) {
            if (next_4_1 < dp_1_5) {
                dp_1_5 = next_4_1;
                dir_1_5 = dir_1_4;
            }
        }
        if (onTheMap_0_3) {
            if (next_4_1 < dp_0_3) {
                dp_0_3 = next_4_1;
                dir_0_3 = dir_1_4;
            }
        }
        double next_5_2 = dp_2_5 + rubble_2_5;
        if (onTheMap_1_5) {
            if (next_5_2 < dp_1_5) {
                dp_1_5 = next_5_2;
                dir_1_5 = dir_2_5;
            }
        }
        if (onTheMap_3_6) {
            if (next_5_2 < dp_3_6) {
                dp_3_6 = next_5_2;
                dir_3_6 = dir_2_5;
            }
        }
        double next_5_4 = dp_4_5 + rubble_4_5;
        if (onTheMap_5_5) {
            if (next_5_4 < dp_5_5) {
                dp_5_5 = next_5_4;
                dir_5_5 = dir_4_5;
            }
        }
        if (onTheMap_3_6) {
            if (next_5_4 < dp_3_6) {
                dp_3_6 = next_5_4;
                dir_3_6 = dir_4_5;
            }
        }
        double next_4_5 = dp_5_4 + rubble_5_4;
        if (onTheMap_5_5) {
            if (next_4_5 < dp_5_5) {
                dp_5_5 = next_4_5;
                dir_5_5 = dir_5_4;
            }
        }
        if (onTheMap_6_3) {
            if (next_4_5 < dp_6_3) {
                dp_6_3 = next_4_5;
                dir_6_3 = dir_5_4;
            }
        }
        double next_2_5 = dp_5_2 + rubble_5_2;
        if (onTheMap_5_1) {
            if (next_2_5 < dp_5_1) {
                dp_5_1 = next_2_5;
                dir_5_1 = dir_5_2;
            }
        }
        if (onTheMap_6_3) {
            if (next_2_5 < dp_6_3) {
                dp_6_3 = next_2_5;
                dir_6_3 = dir_5_2;
            }
        }
        double next_1_4 = dp_4_1 + rubble_4_1;
        if (onTheMap_5_1) {
            if (next_1_4 < dp_5_1) {
                dp_5_1 = next_1_4;
                dir_5_1 = dir_4_1;
            }
        }
        if (onTheMap_3_0) {
            if (next_1_4 < dp_3_0) {
                dp_3_0 = next_1_4;
                dir_3_0 = dir_4_1;
            }
        }
        switch (target.x - ourLocationX) {
            case -3:
                if (target.y - ourLocationY == 0) {
                    return dir_3_0;
                }
                break;
            case -2:
                switch (target.y - ourLocationY) {
                    case -2:
                        return dir_1_1;
                    case -1:
                        return dir_2_1;
                    case 0:
                        return dir_3_1;
                    case 1:
                        return dir_4_1;
                    case 2:
                        return dir_5_1;
                }
                break;
            case -1:
                switch (target.y - ourLocationY) {
                    case -2:
                        return dir_1_2;
                    case -1:
                        return dir_2_2;
                    case 0:
                        return dir_3_2;
                    case 1:
                        return dir_4_2;
                    case 2:
                        return dir_5_2;
                }
                break;
            case 0:
                switch (target.y - ourLocationY) {
                    case -3:
                        return dir_0_3;
                    case -2:
                        return dir_1_3;
                    case -1:
                        return dir_2_3;
                    case 0:
                        return dir_3_3;
                    case 1:
                        return dir_4_3;
                    case 2:
                        return dir_5_3;
                    case 3:
                        return dir_6_3;
                }
                break;
            case 1:
                switch (target.y - ourLocationY) {
                    case -2:
                        return dir_1_4;
                    case -1:
                        return dir_2_4;
                    case 0:
                        return dir_3_4;
                    case 1:
                        return dir_4_4;
                    case 2:
                        return dir_5_4;
                }
                break;
            case 2:
                switch (target.y - ourLocationY) {
                    case -2:
                        return dir_1_5;
                    case -1:
                        return dir_2_5;
                    case 0:
                        return dir_3_5;
                    case 1:
                        return dir_4_5;
                    case 2:
                        return dir_5_5;
                }
                break;
            case 3:
                if (target.y - ourLocationY == 0) {
                    return dir_3_6;
                }
                break;
        }
        Direction bestDir = null;
        double bestScore = Double.MAX_VALUE;
        if (onTheMap_2_1) {
            double score = dp_2_1 + rubble_2_1 + Math.sqrt(loc_2_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_2_1;
            }
        }
        if (onTheMap_1_1) {
            double score = dp_1_1 + rubble_1_1 + Math.sqrt(loc_1_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_1;
            }
        }
        if (onTheMap_1_2) {
            double score = dp_1_2 + rubble_1_2 + Math.sqrt(loc_1_2.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_2;
            }
        }
        if (onTheMap_0_3) {
            double score = dp_0_3 + rubble_0_3 + Math.sqrt(loc_0_3.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_3;
            }
        }
        if (onTheMap_1_3) {
            double score = dp_1_3 + rubble_1_3 + Math.sqrt(loc_1_3.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_3;
            }
        }
        if (onTheMap_1_4) {
            double score = dp_1_4 + rubble_1_4 + Math.sqrt(loc_1_4.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_4;
            }
        }
        if (onTheMap_1_5) {
            double score = dp_1_5 + rubble_1_5 + Math.sqrt(loc_1_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_5;
            }
        }
        if (onTheMap_2_5) {
            double score = dp_2_5 + rubble_2_5 + Math.sqrt(loc_2_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_2_5;
            }
        }
        if (onTheMap_3_5) {
            double score = dp_3_5 + rubble_3_5 + Math.sqrt(loc_3_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_3_5;
            }
        }
        if (onTheMap_3_6) {
            double score = dp_3_6 + rubble_3_6 + Math.sqrt(loc_3_6.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_3_6;
            }
        }
        if (onTheMap_4_5) {
            double score = dp_4_5 + rubble_4_5 + Math.sqrt(loc_4_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_4_5;
            }
        }
        if (onTheMap_5_5) {
            double score = dp_5_5 + rubble_5_5 + Math.sqrt(loc_5_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_5_5;
            }
        }
        if (onTheMap_5_4) {
            double score = dp_5_4 + rubble_5_4 + Math.sqrt(loc_5_4.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_5_4;
            }
        }
        if (onTheMap_5_3) {
            double score = dp_5_3 + rubble_5_3 + Math.sqrt(loc_5_3.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_5_3;
            }
        }
        if (onTheMap_6_3) {
            double score = dp_6_3 + rubble_6_3 + Math.sqrt(loc_6_3.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_6_3;
            }
        }
        if (onTheMap_5_2) {
            double score = dp_5_2 + rubble_5_2 + Math.sqrt(loc_5_2.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_5_2;
            }
        }
        if (onTheMap_5_1) {
            double score = dp_5_1 + rubble_5_1 + Math.sqrt(loc_5_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_5_1;
            }
        }
        if (onTheMap_4_1) {
            double score = dp_4_1 + rubble_4_1 + Math.sqrt(loc_4_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_4_1;
            }
        }
        if (onTheMap_3_0) {
            double score = dp_3_0 + rubble_3_0 + Math.sqrt(loc_3_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_3_0;
            }
        }
        if (onTheMap_3_1) {
            double score = dp_3_1 + rubble_3_1 + Math.sqrt(loc_3_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestDir = dir_3_1;
            }
        }
        return bestDir;
    }
}
