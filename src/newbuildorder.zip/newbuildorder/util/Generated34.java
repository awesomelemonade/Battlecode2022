package newbuildorder.util;

import battlecode.common.Direction;
import battlecode.common.GameActionException;
import battlecode.common.MapLocation;

import static newbuildorder.util.Constants.rc;

public class Generated34 {
    public static Direction ret;

    public static void debug_execute(MapLocation target) throws GameActionException {
        ret = execute(target);
    }
    public static double dp_4_0;
    public static Direction dir_4_0;
    public static double rubble_4_0;
    public static boolean onTheMap_4_0;
    public static MapLocation loc_4_0;
    public static double dp_4_1;
    public static Direction dir_4_1;
    public static double rubble_4_1;
    public static boolean onTheMap_4_1;
    public static MapLocation loc_4_1;
    public static double dp_4_2;
    public static Direction dir_4_2;
    public static double rubble_4_2;
    public static boolean onTheMap_4_2;
    public static MapLocation loc_4_2;
    public static double dp_3_0;
    public static Direction dir_3_0;
    public static double rubble_3_0;
    public static boolean onTheMap_3_0;
    public static MapLocation loc_3_0;
    public static double dp_3_1;
    public static Direction dir_3_1;
    public static double rubble_3_1;
    public static boolean onTheMap_3_1;
    public static MapLocation loc_3_1;
    public static double dp_4_3;
    public static Direction dir_4_3;
    public static double rubble_4_3;
    public static boolean onTheMap_4_3;
    public static MapLocation loc_4_3;
    public static double dp_2_0;
    public static Direction dir_2_0;
    public static double rubble_2_0;
    public static boolean onTheMap_2_0;
    public static MapLocation loc_2_0;
    public static double dp_3_2;
    public static Direction dir_3_2;
    public static double rubble_3_2;
    public static boolean onTheMap_3_2;
    public static MapLocation loc_3_2;
    public static double dp_2_1;
    public static Direction dir_2_1;
    public static double rubble_2_1;
    public static boolean onTheMap_2_1;
    public static MapLocation loc_2_1;
    public static double dp_1_1;
    public static Direction dir_1_1;
    public static double rubble_1_1;
    public static boolean onTheMap_1_1;
    public static MapLocation loc_1_1;
    public static double dp_2_2;
    public static Direction dir_2_2;
    public static double rubble_2_2;
    public static boolean onTheMap_2_2;
    public static MapLocation loc_2_2;
    public static double dp_3_3;
    public static Direction dir_3_3;
    public static double rubble_3_3;
    public static boolean onTheMap_3_3;
    public static MapLocation loc_3_3;
    public static double dp_4_4;
    public static Direction dir_4_4;
    public static double rubble_4_4;
    public static boolean onTheMap_4_4;
    public static MapLocation loc_4_4;
    public static double dp_1_2;
    public static Direction dir_1_2;
    public static double rubble_1_2;
    public static boolean onTheMap_1_2;
    public static MapLocation loc_1_2;
    public static double dp_2_3;
    public static Direction dir_2_3;
    public static double rubble_2_3;
    public static boolean onTheMap_2_3;
    public static MapLocation loc_2_3;
    public static double dp_0_2;
    public static Direction dir_0_2;
    public static double rubble_0_2;
    public static boolean onTheMap_0_2;
    public static MapLocation loc_0_2;
    public static double dp_1_3;
    public static Direction dir_1_3;
    public static double rubble_1_3;
    public static boolean onTheMap_1_3;
    public static MapLocation loc_1_3;
    public static double dp_3_4;
    public static Direction dir_3_4;
    public static double rubble_3_4;
    public static boolean onTheMap_3_4;
    public static MapLocation loc_3_4;
    public static double dp_0_3;
    public static Direction dir_0_3;
    public static double rubble_0_3;
    public static boolean onTheMap_0_3;
    public static MapLocation loc_0_3;
    public static double dp_2_4;
    public static Direction dir_2_4;
    public static double rubble_2_4;
    public static boolean onTheMap_2_4;
    public static MapLocation loc_2_4;
    public static double dp_1_4;
    public static Direction dir_1_4;
    public static double rubble_1_4;
    public static boolean onTheMap_1_4;
    public static MapLocation loc_1_4;
    public static double dp_0_4;
    public static Direction dir_0_4;
    public static double rubble_0_4;
    public static boolean onTheMap_0_4;
    public static MapLocation loc_0_4;
    public static double dp_0_5;
    public static Direction dir_0_5;
    public static double rubble_0_5;
    public static boolean onTheMap_0_5;
    public static MapLocation loc_0_5;
    public static double dp_1_5;
    public static Direction dir_1_5;
    public static double rubble_1_5;
    public static boolean onTheMap_1_5;
    public static MapLocation loc_1_5;
    public static double dp_2_5;
    public static Direction dir_2_5;
    public static double rubble_2_5;
    public static boolean onTheMap_2_5;
    public static MapLocation loc_2_5;
    public static double dp_3_5;
    public static Direction dir_3_5;
    public static double rubble_3_5;
    public static boolean onTheMap_3_5;
    public static MapLocation loc_3_5;
    public static double dp_4_5;
    public static Direction dir_4_5;
    public static double rubble_4_5;
    public static boolean onTheMap_4_5;
    public static MapLocation loc_4_5;
    public static double dp_0_6;
    public static Direction dir_0_6;
    public static double rubble_0_6;
    public static boolean onTheMap_0_6;
    public static MapLocation loc_0_6;
    public static double dp_1_6;
    public static Direction dir_1_6;
    public static double rubble_1_6;
    public static boolean onTheMap_1_6;
    public static MapLocation loc_1_6;
    public static double dp_2_6;
    public static Direction dir_2_6;
    public static double rubble_2_6;
    public static boolean onTheMap_2_6;
    public static MapLocation loc_2_6;
    public static double dp_0_7;
    public static Direction dir_0_7;
    public static double rubble_0_7;
    public static boolean onTheMap_0_7;
    public static MapLocation loc_0_7;
    public static double dp_3_6;
    public static Direction dir_3_6;
    public static double rubble_3_6;
    public static boolean onTheMap_3_6;
    public static MapLocation loc_3_6;
    public static double dp_1_7;
    public static Direction dir_1_7;
    public static double rubble_1_7;
    public static boolean onTheMap_1_7;
    public static MapLocation loc_1_7;
    public static double dp_0_8;
    public static Direction dir_0_8;
    public static double rubble_0_8;
    public static boolean onTheMap_0_8;
    public static MapLocation loc_0_8;
    public static double dp_2_7;
    public static Direction dir_2_7;
    public static double rubble_2_7;
    public static boolean onTheMap_2_7;
    public static MapLocation loc_2_7;
    public static double dp_1_8;
    public static Direction dir_1_8;
    public static double rubble_1_8;
    public static boolean onTheMap_1_8;
    public static MapLocation loc_1_8;
    public static double dp_4_6;
    public static Direction dir_4_6;
    public static double rubble_4_6;
    public static boolean onTheMap_4_6;
    public static MapLocation loc_4_6;
    public static double dp_3_7;
    public static Direction dir_3_7;
    public static double rubble_3_7;
    public static boolean onTheMap_3_7;
    public static MapLocation loc_3_7;
    public static double dp_2_8;
    public static Direction dir_2_8;
    public static double rubble_2_8;
    public static boolean onTheMap_2_8;
    public static MapLocation loc_2_8;
    public static double dp_1_9;
    public static Direction dir_1_9;
    public static double rubble_1_9;
    public static boolean onTheMap_1_9;
    public static MapLocation loc_1_9;
    public static double dp_2_9;
    public static Direction dir_2_9;
    public static double rubble_2_9;
    public static boolean onTheMap_2_9;
    public static MapLocation loc_2_9;
    public static double dp_3_8;
    public static Direction dir_3_8;
    public static double rubble_3_8;
    public static boolean onTheMap_3_8;
    public static MapLocation loc_3_8;
    public static double dp_2_10;
    public static Direction dir_2_10;
    public static double rubble_2_10;
    public static boolean onTheMap_2_10;
    public static MapLocation loc_2_10;
    public static double dp_4_7;
    public static Direction dir_4_7;
    public static double rubble_4_7;
    public static boolean onTheMap_4_7;
    public static MapLocation loc_4_7;
    public static double dp_3_9;
    public static Direction dir_3_9;
    public static double rubble_3_9;
    public static boolean onTheMap_3_9;
    public static MapLocation loc_3_9;
    public static double dp_3_10;
    public static Direction dir_3_10;
    public static double rubble_3_10;
    public static boolean onTheMap_3_10;
    public static MapLocation loc_3_10;
    public static double dp_4_8;
    public static Direction dir_4_8;
    public static double rubble_4_8;
    public static boolean onTheMap_4_8;
    public static MapLocation loc_4_8;
    public static double dp_4_9;
    public static Direction dir_4_9;
    public static double rubble_4_9;
    public static boolean onTheMap_4_9;
    public static MapLocation loc_4_9;
    public static double dp_4_10;
    public static Direction dir_4_10;
    public static double rubble_4_10;
    public static boolean onTheMap_4_10;
    public static MapLocation loc_4_10;
    public static double dp_5_5;
    public static Direction dir_5_5;
    public static double rubble_5_5;
    public static boolean onTheMap_5_5;
    public static MapLocation ourLocation;
    public static double dp_5_6;
    public static Direction dir_5_6;
    public static double rubble_5_6;
    public static boolean onTheMap_5_6;
    public static MapLocation loc_5_6;
    public static double dp_5_7;
    public static Direction dir_5_7;
    public static double rubble_5_7;
    public static boolean onTheMap_5_7;
    public static MapLocation loc_5_7;
    public static double dp_5_8;
    public static Direction dir_5_8;
    public static double rubble_5_8;
    public static boolean onTheMap_5_8;
    public static MapLocation loc_5_8;
    public static double dp_5_9;
    public static Direction dir_5_9;
    public static double rubble_5_9;
    public static boolean onTheMap_5_9;
    public static MapLocation loc_5_9;
    public static double dp_5_10;
    public static Direction dir_5_10;
    public static double rubble_5_10;
    public static boolean onTheMap_5_10;
    public static MapLocation loc_5_10;
    public static double dp_6_10;
    public static Direction dir_6_10;
    public static double rubble_6_10;
    public static boolean onTheMap_6_10;
    public static MapLocation loc_6_10;
    public static double dp_6_9;
    public static Direction dir_6_9;
    public static double rubble_6_9;
    public static boolean onTheMap_6_9;
    public static MapLocation loc_6_9;
    public static double dp_6_8;
    public static Direction dir_6_8;
    public static double rubble_6_8;
    public static boolean onTheMap_6_8;
    public static MapLocation loc_6_8;
    public static double dp_7_10;
    public static Direction dir_7_10;
    public static double rubble_7_10;
    public static boolean onTheMap_7_10;
    public static MapLocation loc_7_10;
    public static double dp_6_7;
    public static Direction dir_6_7;
    public static double rubble_6_7;
    public static boolean onTheMap_6_7;
    public static MapLocation loc_6_7;
    public static double dp_7_9;
    public static Direction dir_7_9;
    public static double rubble_7_9;
    public static boolean onTheMap_7_9;
    public static MapLocation loc_7_9;
    public static double dp_8_10;
    public static Direction dir_8_10;
    public static double rubble_8_10;
    public static boolean onTheMap_8_10;
    public static MapLocation loc_8_10;
    public static double dp_7_8;
    public static Direction dir_7_8;
    public static double rubble_7_8;
    public static boolean onTheMap_7_8;
    public static MapLocation loc_7_8;
    public static double dp_8_9;
    public static Direction dir_8_9;
    public static double rubble_8_9;
    public static boolean onTheMap_8_9;
    public static MapLocation loc_8_9;
    public static double dp_6_6;
    public static Direction dir_6_6;
    public static double rubble_6_6;
    public static boolean onTheMap_6_6;
    public static MapLocation loc_6_6;
    public static double dp_7_7;
    public static Direction dir_7_7;
    public static double rubble_7_7;
    public static boolean onTheMap_7_7;
    public static MapLocation loc_7_7;
    public static double dp_8_8;
    public static Direction dir_8_8;
    public static double rubble_8_8;
    public static boolean onTheMap_8_8;
    public static MapLocation loc_8_8;
    public static double dp_9_9;
    public static Direction dir_9_9;
    public static double rubble_9_9;
    public static boolean onTheMap_9_9;
    public static MapLocation loc_9_9;
    public static double dp_9_8;
    public static Direction dir_9_8;
    public static double rubble_9_8;
    public static boolean onTheMap_9_8;
    public static MapLocation loc_9_8;
    public static double dp_8_7;
    public static Direction dir_8_7;
    public static double rubble_8_7;
    public static boolean onTheMap_8_7;
    public static MapLocation loc_8_7;
    public static double dp_10_8;
    public static Direction dir_10_8;
    public static double rubble_10_8;
    public static boolean onTheMap_10_8;
    public static MapLocation loc_10_8;
    public static double dp_7_6;
    public static Direction dir_7_6;
    public static double rubble_7_6;
    public static boolean onTheMap_7_6;
    public static MapLocation loc_7_6;
    public static double dp_9_7;
    public static Direction dir_9_7;
    public static double rubble_9_7;
    public static boolean onTheMap_9_7;
    public static MapLocation loc_9_7;
    public static double dp_10_7;
    public static Direction dir_10_7;
    public static double rubble_10_7;
    public static boolean onTheMap_10_7;
    public static MapLocation loc_10_7;
    public static double dp_8_6;
    public static Direction dir_8_6;
    public static double rubble_8_6;
    public static boolean onTheMap_8_6;
    public static MapLocation loc_8_6;
    public static double dp_9_6;
    public static Direction dir_9_6;
    public static double rubble_9_6;
    public static boolean onTheMap_9_6;
    public static MapLocation loc_9_6;
    public static double dp_10_6;
    public static Direction dir_10_6;
    public static double rubble_10_6;
    public static boolean onTheMap_10_6;
    public static MapLocation loc_10_6;
    public static double dp_6_5;
    public static Direction dir_6_5;
    public static double rubble_6_5;
    public static boolean onTheMap_6_5;
    public static MapLocation loc_6_5;
    public static double dp_7_5;
    public static Direction dir_7_5;
    public static double rubble_7_5;
    public static boolean onTheMap_7_5;
    public static MapLocation loc_7_5;
    public static double dp_8_5;
    public static Direction dir_8_5;
    public static double rubble_8_5;
    public static boolean onTheMap_8_5;
    public static MapLocation loc_8_5;
    public static double dp_9_5;
    public static Direction dir_9_5;
    public static double rubble_9_5;
    public static boolean onTheMap_9_5;
    public static MapLocation loc_9_5;
    public static double dp_10_5;
    public static Direction dir_10_5;
    public static double rubble_10_5;
    public static boolean onTheMap_10_5;
    public static MapLocation loc_10_5;
    public static double dp_10_4;
    public static Direction dir_10_4;
    public static double rubble_10_4;
    public static boolean onTheMap_10_4;
    public static MapLocation loc_10_4;
    public static double dp_9_4;
    public static Direction dir_9_4;
    public static double rubble_9_4;
    public static boolean onTheMap_9_4;
    public static MapLocation loc_9_4;
    public static double dp_8_4;
    public static Direction dir_8_4;
    public static double rubble_8_4;
    public static boolean onTheMap_8_4;
    public static MapLocation loc_8_4;
    public static double dp_10_3;
    public static Direction dir_10_3;
    public static double rubble_10_3;
    public static boolean onTheMap_10_3;
    public static MapLocation loc_10_3;
    public static double dp_9_3;
    public static Direction dir_9_3;
    public static double rubble_9_3;
    public static boolean onTheMap_9_3;
    public static MapLocation loc_9_3;
    public static double dp_7_4;
    public static Direction dir_7_4;
    public static double rubble_7_4;
    public static boolean onTheMap_7_4;
    public static MapLocation loc_7_4;
    public static double dp_10_2;
    public static Direction dir_10_2;
    public static double rubble_10_2;
    public static boolean onTheMap_10_2;
    public static MapLocation loc_10_2;
    public static double dp_8_3;
    public static Direction dir_8_3;
    public static double rubble_8_3;
    public static boolean onTheMap_8_3;
    public static MapLocation loc_8_3;
    public static double dp_9_2;
    public static Direction dir_9_2;
    public static double rubble_9_2;
    public static boolean onTheMap_9_2;
    public static MapLocation loc_9_2;
    public static double dp_9_1;
    public static Direction dir_9_1;
    public static double rubble_9_1;
    public static boolean onTheMap_9_1;
    public static MapLocation loc_9_1;
    public static double dp_8_2;
    public static Direction dir_8_2;
    public static double rubble_8_2;
    public static boolean onTheMap_8_2;
    public static MapLocation loc_8_2;
    public static double dp_7_3;
    public static Direction dir_7_3;
    public static double rubble_7_3;
    public static boolean onTheMap_7_3;
    public static MapLocation loc_7_3;
    public static double dp_6_4;
    public static Direction dir_6_4;
    public static double rubble_6_4;
    public static boolean onTheMap_6_4;
    public static MapLocation loc_6_4;
    public static double dp_8_1;
    public static Direction dir_8_1;
    public static double rubble_8_1;
    public static boolean onTheMap_8_1;
    public static MapLocation loc_8_1;
    public static double dp_7_2;
    public static Direction dir_7_2;
    public static double rubble_7_2;
    public static boolean onTheMap_7_2;
    public static MapLocation loc_7_2;
    public static double dp_8_0;
    public static Direction dir_8_0;
    public static double rubble_8_0;
    public static boolean onTheMap_8_0;
    public static MapLocation loc_8_0;
    public static double dp_7_1;
    public static Direction dir_7_1;
    public static double rubble_7_1;
    public static boolean onTheMap_7_1;
    public static MapLocation loc_7_1;
    public static double dp_6_3;
    public static Direction dir_6_3;
    public static double rubble_6_3;
    public static boolean onTheMap_6_3;
    public static MapLocation loc_6_3;
    public static double dp_7_0;
    public static Direction dir_7_0;
    public static double rubble_7_0;
    public static boolean onTheMap_7_0;
    public static MapLocation loc_7_0;
    public static double dp_6_2;
    public static Direction dir_6_2;
    public static double rubble_6_2;
    public static boolean onTheMap_6_2;
    public static MapLocation loc_6_2;
    public static double dp_6_1;
    public static Direction dir_6_1;
    public static double rubble_6_1;
    public static boolean onTheMap_6_1;
    public static MapLocation loc_6_1;
    public static double dp_6_0;
    public static Direction dir_6_0;
    public static double rubble_6_0;
    public static boolean onTheMap_6_0;
    public static MapLocation loc_6_0;
    public static double dp_5_0;
    public static Direction dir_5_0;
    public static double rubble_5_0;
    public static boolean onTheMap_5_0;
    public static MapLocation loc_5_0;
    public static double dp_5_1;
    public static Direction dir_5_1;
    public static double rubble_5_1;
    public static boolean onTheMap_5_1;
    public static MapLocation loc_5_1;
    public static double dp_5_2;
    public static Direction dir_5_2;
    public static double rubble_5_2;
    public static boolean onTheMap_5_2;
    public static MapLocation loc_5_2;
    public static double dp_5_3;
    public static Direction dir_5_3;
    public static double rubble_5_3;
    public static boolean onTheMap_5_3;
    public static MapLocation loc_5_3;
    public static double dp_5_4;
    public static Direction dir_5_4;
    public static double rubble_5_4;
    public static boolean onTheMap_5_4;
    public static MapLocation loc_5_4;
    public static Direction execute(MapLocation target) throws GameActionException {
        ourLocation = rc.getLocation();
        if(ourLocation.equals(target)) {
            return Direction.CENTER;
        }
        int ourLocationX = ourLocation.x;
        int ourLocationY = ourLocation.y;
        loc_4_5 = rc.adjacentLocation(Direction.SOUTH);
        loc_6_5 = rc.adjacentLocation(Direction.NORTH);
        loc_3_5 = loc_4_5.add(Direction.SOUTH);
        loc_7_5 = loc_6_5.add(Direction.NORTH);
        loc_2_5 = loc_3_5.add(Direction.SOUTH);
        loc_8_5 = loc_7_5.add(Direction.NORTH);
        loc_1_5 = loc_2_5.add(Direction.SOUTH);
        loc_9_5 = loc_8_5.add(Direction.NORTH);
        loc_0_5 = loc_1_5.add(Direction.SOUTH);
        loc_10_5 = loc_9_5.add(Direction.NORTH);
        loc_5_6 = rc.adjacentLocation(Direction.EAST);
        loc_5_4 = rc.adjacentLocation(Direction.WEST);
        loc_4_4 = rc.adjacentLocation(Direction.SOUTHWEST);
        loc_4_6 = rc.adjacentLocation(Direction.SOUTHEAST);
        loc_6_6 = rc.adjacentLocation(Direction.NORTHEAST);
        loc_6_4 = rc.adjacentLocation(Direction.NORTHWEST);
        loc_3_4 = loc_3_5.add(Direction.WEST);
        loc_3_6 = loc_3_5.add(Direction.EAST);
        loc_7_6 = loc_7_5.add(Direction.EAST);
        loc_7_4 = loc_7_5.add(Direction.WEST);
        loc_2_4 = loc_2_5.add(Direction.WEST);
        loc_2_6 = loc_2_5.add(Direction.EAST);
        loc_8_6 = loc_8_5.add(Direction.EAST);
        loc_8_4 = loc_8_5.add(Direction.WEST);
        loc_1_4 = loc_1_5.add(Direction.WEST);
        loc_1_6 = loc_1_5.add(Direction.EAST);
        loc_9_6 = loc_9_5.add(Direction.EAST);
        loc_9_4 = loc_9_5.add(Direction.WEST);
        loc_0_4 = loc_0_5.add(Direction.WEST);
        loc_0_6 = loc_0_5.add(Direction.EAST);
        loc_10_6 = loc_10_5.add(Direction.EAST);
        loc_10_4 = loc_10_5.add(Direction.WEST);
        loc_5_7 = loc_5_6.add(Direction.EAST);
        loc_5_3 = loc_5_4.add(Direction.WEST);
        loc_4_3 = loc_4_4.add(Direction.WEST);
        loc_4_7 = loc_4_6.add(Direction.EAST);
        loc_6_7 = loc_6_6.add(Direction.EAST);
        loc_6_3 = loc_6_4.add(Direction.WEST);
        loc_3_3 = loc_3_4.add(Direction.WEST);
        loc_3_7 = loc_3_6.add(Direction.EAST);
        loc_7_7 = loc_7_6.add(Direction.EAST);
        loc_7_3 = loc_7_4.add(Direction.WEST);
        loc_2_3 = loc_2_4.add(Direction.WEST);
        loc_2_7 = loc_2_6.add(Direction.EAST);
        loc_8_7 = loc_8_6.add(Direction.EAST);
        loc_8_3 = loc_8_4.add(Direction.WEST);
        loc_1_3 = loc_1_4.add(Direction.WEST);
        loc_1_7 = loc_1_6.add(Direction.EAST);
        loc_9_7 = loc_9_6.add(Direction.EAST);
        loc_9_3 = loc_9_4.add(Direction.WEST);
        loc_0_3 = loc_0_4.add(Direction.WEST);
        loc_0_7 = loc_0_6.add(Direction.EAST);
        loc_10_7 = loc_10_6.add(Direction.EAST);
        loc_10_3 = loc_10_4.add(Direction.WEST);
        loc_5_8 = loc_5_7.add(Direction.EAST);
        loc_5_2 = loc_5_3.add(Direction.WEST);
        loc_4_2 = loc_4_3.add(Direction.WEST);
        loc_4_8 = loc_4_7.add(Direction.EAST);
        loc_6_8 = loc_6_7.add(Direction.EAST);
        loc_6_2 = loc_6_3.add(Direction.WEST);
        loc_3_2 = loc_3_3.add(Direction.WEST);
        loc_3_8 = loc_3_7.add(Direction.EAST);
        loc_7_8 = loc_7_7.add(Direction.EAST);
        loc_7_2 = loc_7_3.add(Direction.WEST);
        loc_2_2 = loc_2_3.add(Direction.WEST);
        loc_2_8 = loc_2_7.add(Direction.EAST);
        loc_8_8 = loc_8_7.add(Direction.EAST);
        loc_8_2 = loc_8_3.add(Direction.WEST);
        loc_1_2 = loc_1_3.add(Direction.WEST);
        loc_1_8 = loc_1_7.add(Direction.EAST);
        loc_9_8 = loc_9_7.add(Direction.EAST);
        loc_9_2 = loc_9_3.add(Direction.WEST);
        loc_0_2 = loc_0_3.add(Direction.WEST);
        loc_0_8 = loc_0_7.add(Direction.EAST);
        loc_10_8 = loc_10_7.add(Direction.EAST);
        loc_10_2 = loc_10_3.add(Direction.WEST);
        loc_5_9 = loc_5_8.add(Direction.EAST);
        loc_5_1 = loc_5_2.add(Direction.WEST);
        loc_4_1 = loc_4_2.add(Direction.WEST);
        loc_4_9 = loc_4_8.add(Direction.EAST);
        loc_6_9 = loc_6_8.add(Direction.EAST);
        loc_6_1 = loc_6_2.add(Direction.WEST);
        loc_3_1 = loc_3_2.add(Direction.WEST);
        loc_3_9 = loc_3_8.add(Direction.EAST);
        loc_7_9 = loc_7_8.add(Direction.EAST);
        loc_7_1 = loc_7_2.add(Direction.WEST);
        loc_2_1 = loc_2_2.add(Direction.WEST);
        loc_2_9 = loc_2_8.add(Direction.EAST);
        loc_8_9 = loc_8_8.add(Direction.EAST);
        loc_8_1 = loc_8_2.add(Direction.WEST);
        loc_1_1 = loc_1_2.add(Direction.WEST);
        loc_1_9 = loc_1_8.add(Direction.EAST);
        loc_9_9 = loc_9_8.add(Direction.EAST);
        loc_9_1 = loc_9_2.add(Direction.WEST);
        loc_5_10 = loc_5_9.add(Direction.EAST);
        loc_5_0 = loc_5_1.add(Direction.WEST);
        loc_4_0 = loc_4_1.add(Direction.WEST);
        loc_4_10 = loc_4_9.add(Direction.EAST);
        loc_6_10 = loc_6_9.add(Direction.EAST);
        loc_6_0 = loc_6_1.add(Direction.WEST);
        loc_3_0 = loc_3_1.add(Direction.WEST);
        loc_3_10 = loc_3_9.add(Direction.EAST);
        loc_7_10 = loc_7_9.add(Direction.EAST);
        loc_7_0 = loc_7_1.add(Direction.WEST);
        loc_2_0 = loc_2_1.add(Direction.WEST);
        loc_2_10 = loc_2_9.add(Direction.EAST);
        loc_8_10 = loc_8_9.add(Direction.EAST);
        loc_8_0 = loc_8_1.add(Direction.WEST);
        dp_4_0 = Double.MAX_VALUE;
        onTheMap_4_0 = rc.onTheMap(loc_4_0);
        if (onTheMap_4_0) {
            rubble_4_0 = 1.0 + rc.senseRubble(loc_4_0) / 10.0;
        }
        dp_4_1 = Double.MAX_VALUE;
        onTheMap_4_1 = rc.onTheMap(loc_4_1);
        if (onTheMap_4_1) {
            rubble_4_1 = 1.0 + rc.senseRubble(loc_4_1) / 10.0;
        }
        dp_4_2 = Double.MAX_VALUE;
        onTheMap_4_2 = rc.onTheMap(loc_4_2);
        if (onTheMap_4_2) {
            rubble_4_2 = 1.0 + rc.senseRubble(loc_4_2) / 10.0;
        }
        dp_3_0 = Double.MAX_VALUE;
        onTheMap_3_0 = rc.onTheMap(loc_3_0);
        if (onTheMap_3_0) {
            rubble_3_0 = 1.0 + rc.senseRubble(loc_3_0) / 10.0;
        }
        dp_3_1 = Double.MAX_VALUE;
        onTheMap_3_1 = rc.onTheMap(loc_3_1);
        if (onTheMap_3_1) {
            rubble_3_1 = 1.0 + rc.senseRubble(loc_3_1) / 10.0;
        }
        dp_4_3 = Double.MAX_VALUE;
        onTheMap_4_3 = rc.onTheMap(loc_4_3);
        if (onTheMap_4_3) {
            rubble_4_3 = 1.0 + rc.senseRubble(loc_4_3) / 10.0;
        }
        dp_2_0 = Double.MAX_VALUE;
        onTheMap_2_0 = rc.onTheMap(loc_2_0);
        if (onTheMap_2_0) {
            rubble_2_0 = 1.0 + rc.senseRubble(loc_2_0) / 10.0;
        }
        dp_3_2 = Double.MAX_VALUE;
        onTheMap_3_2 = rc.onTheMap(loc_3_2);
        if (onTheMap_3_2) {
            rubble_3_2 = 1.0 + rc.senseRubble(loc_3_2) / 10.0;
        }
        dp_2_1 = Double.MAX_VALUE;
        onTheMap_2_1 = rc.onTheMap(loc_2_1);
        if (onTheMap_2_1) {
            rubble_2_1 = 1.0 + rc.senseRubble(loc_2_1) / 10.0;
        }
        dp_1_1 = Double.MAX_VALUE;
        onTheMap_1_1 = rc.onTheMap(loc_1_1);
        if (onTheMap_1_1) {
            rubble_1_1 = 1.0 + rc.senseRubble(loc_1_1) / 10.0;
        }
        dp_2_2 = Double.MAX_VALUE;
        onTheMap_2_2 = rc.onTheMap(loc_2_2);
        if (onTheMap_2_2) {
            rubble_2_2 = 1.0 + rc.senseRubble(loc_2_2) / 10.0;
        }
        dp_3_3 = Double.MAX_VALUE;
        onTheMap_3_3 = rc.onTheMap(loc_3_3);
        if (onTheMap_3_3) {
            rubble_3_3 = 1.0 + rc.senseRubble(loc_3_3) / 10.0;
        }
        dp_4_4 = Double.MAX_VALUE;
        onTheMap_4_4 = rc.onTheMap(loc_4_4);
        if (onTheMap_4_4) {
            rubble_4_4 = 1.0 + rc.senseRubble(loc_4_4) / 10.0;
        }
        dp_1_2 = Double.MAX_VALUE;
        onTheMap_1_2 = rc.onTheMap(loc_1_2);
        if (onTheMap_1_2) {
            rubble_1_2 = 1.0 + rc.senseRubble(loc_1_2) / 10.0;
        }
        dp_2_3 = Double.MAX_VALUE;
        onTheMap_2_3 = rc.onTheMap(loc_2_3);
        if (onTheMap_2_3) {
            rubble_2_3 = 1.0 + rc.senseRubble(loc_2_3) / 10.0;
        }
        dp_0_2 = Double.MAX_VALUE;
        onTheMap_0_2 = rc.onTheMap(loc_0_2);
        if (onTheMap_0_2) {
            rubble_0_2 = 1.0 + rc.senseRubble(loc_0_2) / 10.0;
        }
        dp_1_3 = Double.MAX_VALUE;
        onTheMap_1_3 = rc.onTheMap(loc_1_3);
        if (onTheMap_1_3) {
            rubble_1_3 = 1.0 + rc.senseRubble(loc_1_3) / 10.0;
        }
        dp_3_4 = Double.MAX_VALUE;
        onTheMap_3_4 = rc.onTheMap(loc_3_4);
        if (onTheMap_3_4) {
            rubble_3_4 = 1.0 + rc.senseRubble(loc_3_4) / 10.0;
        }
        dp_0_3 = Double.MAX_VALUE;
        onTheMap_0_3 = rc.onTheMap(loc_0_3);
        if (onTheMap_0_3) {
            rubble_0_3 = 1.0 + rc.senseRubble(loc_0_3) / 10.0;
        }
        dp_2_4 = Double.MAX_VALUE;
        onTheMap_2_4 = rc.onTheMap(loc_2_4);
        if (onTheMap_2_4) {
            rubble_2_4 = 1.0 + rc.senseRubble(loc_2_4) / 10.0;
        }
        dp_1_4 = Double.MAX_VALUE;
        onTheMap_1_4 = rc.onTheMap(loc_1_4);
        if (onTheMap_1_4) {
            rubble_1_4 = 1.0 + rc.senseRubble(loc_1_4) / 10.0;
        }
        dp_0_4 = Double.MAX_VALUE;
        onTheMap_0_4 = rc.onTheMap(loc_0_4);
        if (onTheMap_0_4) {
            rubble_0_4 = 1.0 + rc.senseRubble(loc_0_4) / 10.0;
        }
        dp_0_5 = Double.MAX_VALUE;
        onTheMap_0_5 = rc.onTheMap(loc_0_5);
        if (onTheMap_0_5) {
            rubble_0_5 = 1.0 + rc.senseRubble(loc_0_5) / 10.0;
        }
        dp_1_5 = Double.MAX_VALUE;
        onTheMap_1_5 = rc.onTheMap(loc_1_5);
        if (onTheMap_1_5) {
            rubble_1_5 = 1.0 + rc.senseRubble(loc_1_5) / 10.0;
        }
        dp_2_5 = Double.MAX_VALUE;
        onTheMap_2_5 = rc.onTheMap(loc_2_5);
        if (onTheMap_2_5) {
            rubble_2_5 = 1.0 + rc.senseRubble(loc_2_5) / 10.0;
        }
        dp_3_5 = Double.MAX_VALUE;
        onTheMap_3_5 = rc.onTheMap(loc_3_5);
        if (onTheMap_3_5) {
            rubble_3_5 = 1.0 + rc.senseRubble(loc_3_5) / 10.0;
        }
        dp_4_5 = Double.MAX_VALUE;
        onTheMap_4_5 = rc.onTheMap(loc_4_5);
        if (onTheMap_4_5) {
            rubble_4_5 = 1.0 + rc.senseRubble(loc_4_5) / 10.0;
        }
        dp_0_6 = Double.MAX_VALUE;
        onTheMap_0_6 = rc.onTheMap(loc_0_6);
        if (onTheMap_0_6) {
            rubble_0_6 = 1.0 + rc.senseRubble(loc_0_6) / 10.0;
        }
        dp_1_6 = Double.MAX_VALUE;
        onTheMap_1_6 = rc.onTheMap(loc_1_6);
        if (onTheMap_1_6) {
            rubble_1_6 = 1.0 + rc.senseRubble(loc_1_6) / 10.0;
        }
        dp_2_6 = Double.MAX_VALUE;
        onTheMap_2_6 = rc.onTheMap(loc_2_6);
        if (onTheMap_2_6) {
            rubble_2_6 = 1.0 + rc.senseRubble(loc_2_6) / 10.0;
        }
        dp_0_7 = Double.MAX_VALUE;
        onTheMap_0_7 = rc.onTheMap(loc_0_7);
        if (onTheMap_0_7) {
            rubble_0_7 = 1.0 + rc.senseRubble(loc_0_7) / 10.0;
        }
        dp_3_6 = Double.MAX_VALUE;
        onTheMap_3_6 = rc.onTheMap(loc_3_6);
        if (onTheMap_3_6) {
            rubble_3_6 = 1.0 + rc.senseRubble(loc_3_6) / 10.0;
        }
        dp_1_7 = Double.MAX_VALUE;
        onTheMap_1_7 = rc.onTheMap(loc_1_7);
        if (onTheMap_1_7) {
            rubble_1_7 = 1.0 + rc.senseRubble(loc_1_7) / 10.0;
        }
        dp_0_8 = Double.MAX_VALUE;
        onTheMap_0_8 = rc.onTheMap(loc_0_8);
        if (onTheMap_0_8) {
            rubble_0_8 = 1.0 + rc.senseRubble(loc_0_8) / 10.0;
        }
        dp_2_7 = Double.MAX_VALUE;
        onTheMap_2_7 = rc.onTheMap(loc_2_7);
        if (onTheMap_2_7) {
            rubble_2_7 = 1.0 + rc.senseRubble(loc_2_7) / 10.0;
        }
        dp_1_8 = Double.MAX_VALUE;
        onTheMap_1_8 = rc.onTheMap(loc_1_8);
        if (onTheMap_1_8) {
            rubble_1_8 = 1.0 + rc.senseRubble(loc_1_8) / 10.0;
        }
        dp_4_6 = Double.MAX_VALUE;
        onTheMap_4_6 = rc.onTheMap(loc_4_6);
        if (onTheMap_4_6) {
            rubble_4_6 = 1.0 + rc.senseRubble(loc_4_6) / 10.0;
        }
        dp_3_7 = Double.MAX_VALUE;
        onTheMap_3_7 = rc.onTheMap(loc_3_7);
        if (onTheMap_3_7) {
            rubble_3_7 = 1.0 + rc.senseRubble(loc_3_7) / 10.0;
        }
        dp_2_8 = Double.MAX_VALUE;
        onTheMap_2_8 = rc.onTheMap(loc_2_8);
        if (onTheMap_2_8) {
            rubble_2_8 = 1.0 + rc.senseRubble(loc_2_8) / 10.0;
        }
        dp_1_9 = Double.MAX_VALUE;
        onTheMap_1_9 = rc.onTheMap(loc_1_9);
        if (onTheMap_1_9) {
            rubble_1_9 = 1.0 + rc.senseRubble(loc_1_9) / 10.0;
        }
        dp_2_9 = Double.MAX_VALUE;
        onTheMap_2_9 = rc.onTheMap(loc_2_9);
        if (onTheMap_2_9) {
            rubble_2_9 = 1.0 + rc.senseRubble(loc_2_9) / 10.0;
        }
        dp_3_8 = Double.MAX_VALUE;
        onTheMap_3_8 = rc.onTheMap(loc_3_8);
        if (onTheMap_3_8) {
            rubble_3_8 = 1.0 + rc.senseRubble(loc_3_8) / 10.0;
        }
        dp_2_10 = Double.MAX_VALUE;
        onTheMap_2_10 = rc.onTheMap(loc_2_10);
        if (onTheMap_2_10) {
            rubble_2_10 = 1.0 + rc.senseRubble(loc_2_10) / 10.0;
        }
        dp_4_7 = Double.MAX_VALUE;
        onTheMap_4_7 = rc.onTheMap(loc_4_7);
        if (onTheMap_4_7) {
            rubble_4_7 = 1.0 + rc.senseRubble(loc_4_7) / 10.0;
        }
        dp_3_9 = Double.MAX_VALUE;
        onTheMap_3_9 = rc.onTheMap(loc_3_9);
        if (onTheMap_3_9) {
            rubble_3_9 = 1.0 + rc.senseRubble(loc_3_9) / 10.0;
        }
        dp_3_10 = Double.MAX_VALUE;
        onTheMap_3_10 = rc.onTheMap(loc_3_10);
        if (onTheMap_3_10) {
            rubble_3_10 = 1.0 + rc.senseRubble(loc_3_10) / 10.0;
        }
        dp_4_8 = Double.MAX_VALUE;
        onTheMap_4_8 = rc.onTheMap(loc_4_8);
        if (onTheMap_4_8) {
            rubble_4_8 = 1.0 + rc.senseRubble(loc_4_8) / 10.0;
        }
        dp_4_9 = Double.MAX_VALUE;
        onTheMap_4_9 = rc.onTheMap(loc_4_9);
        if (onTheMap_4_9) {
            rubble_4_9 = 1.0 + rc.senseRubble(loc_4_9) / 10.0;
        }
        dp_4_10 = Double.MAX_VALUE;
        onTheMap_4_10 = rc.onTheMap(loc_4_10);
        if (onTheMap_4_10) {
            rubble_4_10 = 1.0 + rc.senseRubble(loc_4_10) / 10.0;
        }
        dp_5_5 = 0;
        onTheMap_5_5 = rc.onTheMap(ourLocation);
        if (onTheMap_5_5) {
            rubble_5_5 = 1.0 + rc.senseRubble(ourLocation) / 10.0;
        }
        dp_5_6 = Double.MAX_VALUE;
        onTheMap_5_6 = rc.onTheMap(loc_5_6);
        if (onTheMap_5_6) {
            rubble_5_6 = 1.0 + rc.senseRubble(loc_5_6) / 10.0;
        }
        dp_5_7 = Double.MAX_VALUE;
        onTheMap_5_7 = rc.onTheMap(loc_5_7);
        if (onTheMap_5_7) {
            rubble_5_7 = 1.0 + rc.senseRubble(loc_5_7) / 10.0;
        }
        dp_5_8 = Double.MAX_VALUE;
        onTheMap_5_8 = rc.onTheMap(loc_5_8);
        if (onTheMap_5_8) {
            rubble_5_8 = 1.0 + rc.senseRubble(loc_5_8) / 10.0;
        }
        dp_5_9 = Double.MAX_VALUE;
        onTheMap_5_9 = rc.onTheMap(loc_5_9);
        if (onTheMap_5_9) {
            rubble_5_9 = 1.0 + rc.senseRubble(loc_5_9) / 10.0;
        }
        dp_5_10 = Double.MAX_VALUE;
        onTheMap_5_10 = rc.onTheMap(loc_5_10);
        if (onTheMap_5_10) {
            rubble_5_10 = 1.0 + rc.senseRubble(loc_5_10) / 10.0;
        }
        dp_6_10 = Double.MAX_VALUE;
        onTheMap_6_10 = rc.onTheMap(loc_6_10);
        if (onTheMap_6_10) {
            rubble_6_10 = 1.0 + rc.senseRubble(loc_6_10) / 10.0;
        }
        dp_6_9 = Double.MAX_VALUE;
        onTheMap_6_9 = rc.onTheMap(loc_6_9);
        if (onTheMap_6_9) {
            rubble_6_9 = 1.0 + rc.senseRubble(loc_6_9) / 10.0;
        }
        dp_6_8 = Double.MAX_VALUE;
        onTheMap_6_8 = rc.onTheMap(loc_6_8);
        if (onTheMap_6_8) {
            rubble_6_8 = 1.0 + rc.senseRubble(loc_6_8) / 10.0;
        }
        dp_7_10 = Double.MAX_VALUE;
        onTheMap_7_10 = rc.onTheMap(loc_7_10);
        if (onTheMap_7_10) {
            rubble_7_10 = 1.0 + rc.senseRubble(loc_7_10) / 10.0;
        }
        dp_6_7 = Double.MAX_VALUE;
        onTheMap_6_7 = rc.onTheMap(loc_6_7);
        if (onTheMap_6_7) {
            rubble_6_7 = 1.0 + rc.senseRubble(loc_6_7) / 10.0;
        }
        dp_7_9 = Double.MAX_VALUE;
        onTheMap_7_9 = rc.onTheMap(loc_7_9);
        if (onTheMap_7_9) {
            rubble_7_9 = 1.0 + rc.senseRubble(loc_7_9) / 10.0;
        }
        dp_8_10 = Double.MAX_VALUE;
        onTheMap_8_10 = rc.onTheMap(loc_8_10);
        if (onTheMap_8_10) {
            rubble_8_10 = 1.0 + rc.senseRubble(loc_8_10) / 10.0;
        }
        dp_7_8 = Double.MAX_VALUE;
        onTheMap_7_8 = rc.onTheMap(loc_7_8);
        if (onTheMap_7_8) {
            rubble_7_8 = 1.0 + rc.senseRubble(loc_7_8) / 10.0;
        }
        dp_8_9 = Double.MAX_VALUE;
        onTheMap_8_9 = rc.onTheMap(loc_8_9);
        if (onTheMap_8_9) {
            rubble_8_9 = 1.0 + rc.senseRubble(loc_8_9) / 10.0;
        }
        dp_6_6 = Double.MAX_VALUE;
        onTheMap_6_6 = rc.onTheMap(loc_6_6);
        if (onTheMap_6_6) {
            rubble_6_6 = 1.0 + rc.senseRubble(loc_6_6) / 10.0;
        }
        dp_7_7 = Double.MAX_VALUE;
        onTheMap_7_7 = rc.onTheMap(loc_7_7);
        if (onTheMap_7_7) {
            rubble_7_7 = 1.0 + rc.senseRubble(loc_7_7) / 10.0;
        }
        dp_8_8 = Double.MAX_VALUE;
        onTheMap_8_8 = rc.onTheMap(loc_8_8);
        if (onTheMap_8_8) {
            rubble_8_8 = 1.0 + rc.senseRubble(loc_8_8) / 10.0;
        }
        dp_9_9 = Double.MAX_VALUE;
        onTheMap_9_9 = rc.onTheMap(loc_9_9);
        if (onTheMap_9_9) {
            rubble_9_9 = 1.0 + rc.senseRubble(loc_9_9) / 10.0;
        }
        dp_9_8 = Double.MAX_VALUE;
        onTheMap_9_8 = rc.onTheMap(loc_9_8);
        if (onTheMap_9_8) {
            rubble_9_8 = 1.0 + rc.senseRubble(loc_9_8) / 10.0;
        }
        dp_8_7 = Double.MAX_VALUE;
        onTheMap_8_7 = rc.onTheMap(loc_8_7);
        if (onTheMap_8_7) {
            rubble_8_7 = 1.0 + rc.senseRubble(loc_8_7) / 10.0;
        }
        dp_10_8 = Double.MAX_VALUE;
        onTheMap_10_8 = rc.onTheMap(loc_10_8);
        if (onTheMap_10_8) {
            rubble_10_8 = 1.0 + rc.senseRubble(loc_10_8) / 10.0;
        }
        dp_7_6 = Double.MAX_VALUE;
        onTheMap_7_6 = rc.onTheMap(loc_7_6);
        if (onTheMap_7_6) {
            rubble_7_6 = 1.0 + rc.senseRubble(loc_7_6) / 10.0;
        }
        dp_9_7 = Double.MAX_VALUE;
        onTheMap_9_7 = rc.onTheMap(loc_9_7);
        if (onTheMap_9_7) {
            rubble_9_7 = 1.0 + rc.senseRubble(loc_9_7) / 10.0;
        }
        dp_10_7 = Double.MAX_VALUE;
        onTheMap_10_7 = rc.onTheMap(loc_10_7);
        if (onTheMap_10_7) {
            rubble_10_7 = 1.0 + rc.senseRubble(loc_10_7) / 10.0;
        }
        dp_8_6 = Double.MAX_VALUE;
        onTheMap_8_6 = rc.onTheMap(loc_8_6);
        if (onTheMap_8_6) {
            rubble_8_6 = 1.0 + rc.senseRubble(loc_8_6) / 10.0;
        }
        dp_9_6 = Double.MAX_VALUE;
        onTheMap_9_6 = rc.onTheMap(loc_9_6);
        if (onTheMap_9_6) {
            rubble_9_6 = 1.0 + rc.senseRubble(loc_9_6) / 10.0;
        }
        dp_10_6 = Double.MAX_VALUE;
        onTheMap_10_6 = rc.onTheMap(loc_10_6);
        if (onTheMap_10_6) {
            rubble_10_6 = 1.0 + rc.senseRubble(loc_10_6) / 10.0;
        }
        dp_6_5 = Double.MAX_VALUE;
        onTheMap_6_5 = rc.onTheMap(loc_6_5);
        if (onTheMap_6_5) {
            rubble_6_5 = 1.0 + rc.senseRubble(loc_6_5) / 10.0;
        }
        dp_7_5 = Double.MAX_VALUE;
        onTheMap_7_5 = rc.onTheMap(loc_7_5);
        if (onTheMap_7_5) {
            rubble_7_5 = 1.0 + rc.senseRubble(loc_7_5) / 10.0;
        }
        dp_8_5 = Double.MAX_VALUE;
        onTheMap_8_5 = rc.onTheMap(loc_8_5);
        if (onTheMap_8_5) {
            rubble_8_5 = 1.0 + rc.senseRubble(loc_8_5) / 10.0;
        }
        dp_9_5 = Double.MAX_VALUE;
        onTheMap_9_5 = rc.onTheMap(loc_9_5);
        if (onTheMap_9_5) {
            rubble_9_5 = 1.0 + rc.senseRubble(loc_9_5) / 10.0;
        }
        dp_10_5 = Double.MAX_VALUE;
        onTheMap_10_5 = rc.onTheMap(loc_10_5);
        if (onTheMap_10_5) {
            rubble_10_5 = 1.0 + rc.senseRubble(loc_10_5) / 10.0;
        }
        dp_10_4 = Double.MAX_VALUE;
        onTheMap_10_4 = rc.onTheMap(loc_10_4);
        if (onTheMap_10_4) {
            rubble_10_4 = 1.0 + rc.senseRubble(loc_10_4) / 10.0;
        }
        dp_9_4 = Double.MAX_VALUE;
        onTheMap_9_4 = rc.onTheMap(loc_9_4);
        if (onTheMap_9_4) {
            rubble_9_4 = 1.0 + rc.senseRubble(loc_9_4) / 10.0;
        }
        dp_8_4 = Double.MAX_VALUE;
        onTheMap_8_4 = rc.onTheMap(loc_8_4);
        if (onTheMap_8_4) {
            rubble_8_4 = 1.0 + rc.senseRubble(loc_8_4) / 10.0;
        }
        dp_10_3 = Double.MAX_VALUE;
        onTheMap_10_3 = rc.onTheMap(loc_10_3);
        if (onTheMap_10_3) {
            rubble_10_3 = 1.0 + rc.senseRubble(loc_10_3) / 10.0;
        }
        dp_9_3 = Double.MAX_VALUE;
        onTheMap_9_3 = rc.onTheMap(loc_9_3);
        if (onTheMap_9_3) {
            rubble_9_3 = 1.0 + rc.senseRubble(loc_9_3) / 10.0;
        }
        dp_7_4 = Double.MAX_VALUE;
        onTheMap_7_4 = rc.onTheMap(loc_7_4);
        if (onTheMap_7_4) {
            rubble_7_4 = 1.0 + rc.senseRubble(loc_7_4) / 10.0;
        }
        dp_10_2 = Double.MAX_VALUE;
        onTheMap_10_2 = rc.onTheMap(loc_10_2);
        if (onTheMap_10_2) {
            rubble_10_2 = 1.0 + rc.senseRubble(loc_10_2) / 10.0;
        }
        dp_8_3 = Double.MAX_VALUE;
        onTheMap_8_3 = rc.onTheMap(loc_8_3);
        if (onTheMap_8_3) {
            rubble_8_3 = 1.0 + rc.senseRubble(loc_8_3) / 10.0;
        }
        dp_9_2 = Double.MAX_VALUE;
        onTheMap_9_2 = rc.onTheMap(loc_9_2);
        if (onTheMap_9_2) {
            rubble_9_2 = 1.0 + rc.senseRubble(loc_9_2) / 10.0;
        }
        dp_9_1 = Double.MAX_VALUE;
        onTheMap_9_1 = rc.onTheMap(loc_9_1);
        if (onTheMap_9_1) {
            rubble_9_1 = 1.0 + rc.senseRubble(loc_9_1) / 10.0;
        }
        dp_8_2 = Double.MAX_VALUE;
        onTheMap_8_2 = rc.onTheMap(loc_8_2);
        if (onTheMap_8_2) {
            rubble_8_2 = 1.0 + rc.senseRubble(loc_8_2) / 10.0;
        }
        dp_7_3 = Double.MAX_VALUE;
        onTheMap_7_3 = rc.onTheMap(loc_7_3);
        if (onTheMap_7_3) {
            rubble_7_3 = 1.0 + rc.senseRubble(loc_7_3) / 10.0;
        }
        dp_6_4 = Double.MAX_VALUE;
        onTheMap_6_4 = rc.onTheMap(loc_6_4);
        if (onTheMap_6_4) {
            rubble_6_4 = 1.0 + rc.senseRubble(loc_6_4) / 10.0;
        }
        dp_8_1 = Double.MAX_VALUE;
        onTheMap_8_1 = rc.onTheMap(loc_8_1);
        if (onTheMap_8_1) {
            rubble_8_1 = 1.0 + rc.senseRubble(loc_8_1) / 10.0;
        }
        dp_7_2 = Double.MAX_VALUE;
        onTheMap_7_2 = rc.onTheMap(loc_7_2);
        if (onTheMap_7_2) {
            rubble_7_2 = 1.0 + rc.senseRubble(loc_7_2) / 10.0;
        }
        dp_8_0 = Double.MAX_VALUE;
        onTheMap_8_0 = rc.onTheMap(loc_8_0);
        if (onTheMap_8_0) {
            rubble_8_0 = 1.0 + rc.senseRubble(loc_8_0) / 10.0;
        }
        dp_7_1 = Double.MAX_VALUE;
        onTheMap_7_1 = rc.onTheMap(loc_7_1);
        if (onTheMap_7_1) {
            rubble_7_1 = 1.0 + rc.senseRubble(loc_7_1) / 10.0;
        }
        dp_6_3 = Double.MAX_VALUE;
        onTheMap_6_3 = rc.onTheMap(loc_6_3);
        if (onTheMap_6_3) {
            rubble_6_3 = 1.0 + rc.senseRubble(loc_6_3) / 10.0;
        }
        dp_7_0 = Double.MAX_VALUE;
        onTheMap_7_0 = rc.onTheMap(loc_7_0);
        if (onTheMap_7_0) {
            rubble_7_0 = 1.0 + rc.senseRubble(loc_7_0) / 10.0;
        }
        dp_6_2 = Double.MAX_VALUE;
        onTheMap_6_2 = rc.onTheMap(loc_6_2);
        if (onTheMap_6_2) {
            rubble_6_2 = 1.0 + rc.senseRubble(loc_6_2) / 10.0;
        }
        dp_6_1 = Double.MAX_VALUE;
        onTheMap_6_1 = rc.onTheMap(loc_6_1);
        if (onTheMap_6_1) {
            rubble_6_1 = 1.0 + rc.senseRubble(loc_6_1) / 10.0;
        }
        dp_6_0 = Double.MAX_VALUE;
        onTheMap_6_0 = rc.onTheMap(loc_6_0);
        if (onTheMap_6_0) {
            rubble_6_0 = 1.0 + rc.senseRubble(loc_6_0) / 10.0;
        }
        dp_5_0 = Double.MAX_VALUE;
        onTheMap_5_0 = rc.onTheMap(loc_5_0);
        if (onTheMap_5_0) {
            rubble_5_0 = 1.0 + rc.senseRubble(loc_5_0) / 10.0;
        }
        dp_5_1 = Double.MAX_VALUE;
        onTheMap_5_1 = rc.onTheMap(loc_5_1);
        if (onTheMap_5_1) {
            rubble_5_1 = 1.0 + rc.senseRubble(loc_5_1) / 10.0;
        }
        dp_5_2 = Double.MAX_VALUE;
        onTheMap_5_2 = rc.onTheMap(loc_5_2);
        if (onTheMap_5_2) {
            rubble_5_2 = 1.0 + rc.senseRubble(loc_5_2) / 10.0;
        }
        dp_5_3 = Double.MAX_VALUE;
        onTheMap_5_3 = rc.onTheMap(loc_5_3);
        if (onTheMap_5_3) {
            rubble_5_3 = 1.0 + rc.senseRubble(loc_5_3) / 10.0;
        }
        dp_5_4 = Double.MAX_VALUE;
        onTheMap_5_4 = rc.onTheMap(loc_5_4);
        if (onTheMap_5_4) {
            rubble_5_4 = 1.0 + rc.senseRubble(loc_5_4) / 10.0;
        }
        if (onTheMap_5_6 && !rc.isLocationOccupied(loc_5_6)) {
            dp_5_6 = rubble_5_5;
            dir_5_6 = Direction.EAST;
        }
        if (onTheMap_6_5 && !rc.isLocationOccupied(loc_6_5)) {
            dp_6_5 = rubble_5_5;
            dir_6_5 = Direction.NORTH;
        }
        if (onTheMap_5_4 && !rc.isLocationOccupied(loc_5_4)) {
            dp_5_4 = rubble_5_5;
            dir_5_4 = Direction.WEST;
        }
        if (onTheMap_4_5 && !rc.isLocationOccupied(loc_4_5)) {
            dp_4_5 = rubble_5_5;
            dir_4_5 = Direction.SOUTH;
        }
        if (onTheMap_6_6 && !rc.isLocationOccupied(loc_6_6)) {
            dp_6_6 = rubble_5_5;
            dir_6_6 = Direction.NORTHEAST;
        }
        if (onTheMap_6_4 && !rc.isLocationOccupied(loc_6_4)) {
            dp_6_4 = rubble_5_5;
            dir_6_4 = Direction.NORTHWEST;
        }
        if (onTheMap_4_4 && !rc.isLocationOccupied(loc_4_4)) {
            dp_4_4 = rubble_5_5;
            dir_4_4 = Direction.SOUTHWEST;
        }
        if (onTheMap_4_6 && !rc.isLocationOccupied(loc_4_6)) {
            dp_4_6 = rubble_5_5;
            dir_4_6 = Direction.SOUTHEAST;
        }
        double next_5_4 = dp_4_5 + rubble_4_5;
        if (onTheMap_3_5) {
            dp_3_5 = next_5_4;
            dir_3_5 = dir_4_5;
        }
        if (onTheMap_3_4) {
            dp_3_4 = next_5_4;
            dir_3_4 = dir_4_5;
        }
        if (onTheMap_3_6) {
            dp_3_6 = next_5_4;
            dir_3_6 = dir_4_5;
        }
        double next_6_5 = dp_5_6 + rubble_5_6;
        if (onTheMap_5_7) {
            dp_5_7 = next_6_5;
            dir_5_7 = dir_5_6;
        }
        if (onTheMap_6_7) {
            dp_6_7 = next_6_5;
            dir_6_7 = dir_5_6;
        }
        if (onTheMap_4_7) {
            dp_4_7 = next_6_5;
            dir_4_7 = dir_5_6;
        }
        double next_5_6 = dp_6_5 + rubble_6_5;
        if (onTheMap_7_5) {
            dp_7_5 = next_5_6;
            dir_7_5 = dir_6_5;
        }
        if (onTheMap_7_6) {
            dp_7_6 = next_5_6;
            dir_7_6 = dir_6_5;
        }
        if (onTheMap_7_4) {
            dp_7_4 = next_5_6;
            dir_7_4 = dir_6_5;
        }
        double next_4_5 = dp_5_4 + rubble_5_4;
        if (onTheMap_5_3) {
            dp_5_3 = next_4_5;
            dir_5_3 = dir_5_4;
        }
        if (onTheMap_6_3) {
            dp_6_3 = next_4_5;
            dir_6_3 = dir_5_4;
        }
        if (onTheMap_4_3) {
            dp_4_3 = next_4_5;
            dir_4_3 = dir_5_4;
        }
        double next_4_4 = dp_4_4 + rubble_4_4;
        if (onTheMap_4_3) {
            if (next_4_4 < dp_4_3) {
                dp_4_3 = next_4_4;
                dir_4_3 = dir_4_4;
            }
        }
        if (onTheMap_3_4) {
            if (next_4_4 < dp_3_4) {
                dp_3_4 = next_4_4;
                dir_3_4 = dir_4_4;
            }
        }
        if (onTheMap_5_3) {
            if (next_4_4 < dp_5_3) {
                dp_5_3 = next_4_4;
                dir_5_3 = dir_4_4;
            }
        }
        if (onTheMap_3_3) {
            dp_3_3 = next_4_4;
            dir_3_3 = dir_4_4;
        }
        if (onTheMap_3_5) {
            if (next_4_4 < dp_3_5) {
                dp_3_5 = next_4_4;
                dir_3_5 = dir_4_4;
            }
        }
        double next_6_4 = dp_4_6 + rubble_4_6;
        if (onTheMap_4_7) {
            if (next_6_4 < dp_4_7) {
                dp_4_7 = next_6_4;
                dir_4_7 = dir_4_6;
            }
        }
        if (onTheMap_3_6) {
            if (next_6_4 < dp_3_6) {
                dp_3_6 = next_6_4;
                dir_3_6 = dir_4_6;
            }
        }
        if (onTheMap_5_7) {
            if (next_6_4 < dp_5_7) {
                dp_5_7 = next_6_4;
                dir_5_7 = dir_4_6;
            }
        }
        if (onTheMap_3_5) {
            if (next_6_4 < dp_3_5) {
                dp_3_5 = next_6_4;
                dir_3_5 = dir_4_6;
            }
        }
        if (onTheMap_3_7) {
            dp_3_7 = next_6_4;
            dir_3_7 = dir_4_6;
        }
        double next_6_6 = dp_6_6 + rubble_6_6;
        if (onTheMap_6_7) {
            if (next_6_6 < dp_6_7) {
                dp_6_7 = next_6_6;
                dir_6_7 = dir_6_6;
            }
        }
        if (onTheMap_7_6) {
            if (next_6_6 < dp_7_6) {
                dp_7_6 = next_6_6;
                dir_7_6 = dir_6_6;
            }
        }
        if (onTheMap_7_7) {
            dp_7_7 = next_6_6;
            dir_7_7 = dir_6_6;
        }
        if (onTheMap_7_5) {
            if (next_6_6 < dp_7_5) {
                dp_7_5 = next_6_6;
                dir_7_5 = dir_6_6;
            }
        }
        if (onTheMap_5_7) {
            if (next_6_6 < dp_5_7) {
                dp_5_7 = next_6_6;
                dir_5_7 = dir_6_6;
            }
        }
        double next_4_6 = dp_6_4 + rubble_6_4;
        if (onTheMap_7_4) {
            if (next_4_6 < dp_7_4) {
                dp_7_4 = next_4_6;
                dir_7_4 = dir_6_4;
            }
        }
        if (onTheMap_6_3) {
            if (next_4_6 < dp_6_3) {
                dp_6_3 = next_4_6;
                dir_6_3 = dir_6_4;
            }
        }
        if (onTheMap_7_5) {
            if (next_4_6 < dp_7_5) {
                dp_7_5 = next_4_6;
                dir_7_5 = dir_6_4;
            }
        }
        if (onTheMap_7_3) {
            dp_7_3 = next_4_6;
            dir_7_3 = dir_6_4;
        }
        if (onTheMap_5_3) {
            if (next_4_6 < dp_5_3) {
                dp_5_3 = next_4_6;
                dir_5_3 = dir_6_4;
            }
        }
        double next_5_3 = dp_3_5 + rubble_3_5;
        if (onTheMap_3_6) {
            if (next_5_3 < dp_3_6) {
                dp_3_6 = next_5_3;
                dir_3_6 = dir_3_5;
            }
        }
        if (onTheMap_3_4) {
            if (next_5_3 < dp_3_4) {
                dp_3_4 = next_5_3;
                dir_3_4 = dir_3_5;
            }
        }
        if (onTheMap_2_5) {
            dp_2_5 = next_5_3;
            dir_2_5 = dir_3_5;
        }
        if (onTheMap_2_4) {
            dp_2_4 = next_5_3;
            dir_2_4 = dir_3_5;
        }
        if (onTheMap_2_6) {
            dp_2_6 = next_5_3;
            dir_2_6 = dir_3_5;
        }
        double next_7_5 = dp_5_7 + rubble_5_7;
        if (onTheMap_5_8) {
            dp_5_8 = next_7_5;
            dir_5_8 = dir_5_7;
        }
        if (onTheMap_6_7) {
            if (next_7_5 < dp_6_7) {
                dp_6_7 = next_7_5;
                dir_6_7 = dir_5_7;
            }
        }
        if (onTheMap_4_7) {
            if (next_7_5 < dp_4_7) {
                dp_4_7 = next_7_5;
                dir_4_7 = dir_5_7;
            }
        }
        if (onTheMap_6_8) {
            dp_6_8 = next_7_5;
            dir_6_8 = dir_5_7;
        }
        if (onTheMap_4_8) {
            dp_4_8 = next_7_5;
            dir_4_8 = dir_5_7;
        }
        double next_5_7 = dp_7_5 + rubble_7_5;
        if (onTheMap_7_6) {
            if (next_5_7 < dp_7_6) {
                dp_7_6 = next_5_7;
                dir_7_6 = dir_7_5;
            }
        }
        if (onTheMap_8_5) {
            dp_8_5 = next_5_7;
            dir_8_5 = dir_7_5;
        }
        if (onTheMap_7_4) {
            if (next_5_7 < dp_7_4) {
                dp_7_4 = next_5_7;
                dir_7_4 = dir_7_5;
            }
        }
        if (onTheMap_8_6) {
            dp_8_6 = next_5_7;
            dir_8_6 = dir_7_5;
        }
        if (onTheMap_8_4) {
            dp_8_4 = next_5_7;
            dir_8_4 = dir_7_5;
        }
        double next_3_5 = dp_5_3 + rubble_5_3;
        if (onTheMap_6_3) {
            if (next_3_5 < dp_6_3) {
                dp_6_3 = next_3_5;
                dir_6_3 = dir_5_3;
            }
        }
        if (onTheMap_5_2) {
            dp_5_2 = next_3_5;
            dir_5_2 = dir_5_3;
        }
        if (onTheMap_4_3) {
            if (next_3_5 < dp_4_3) {
                dp_4_3 = next_3_5;
                dir_4_3 = dir_5_3;
            }
        }
        if (onTheMap_6_2) {
            dp_6_2 = next_3_5;
            dir_6_2 = dir_5_3;
        }
        if (onTheMap_4_2) {
            dp_4_2 = next_3_5;
            dir_4_2 = dir_5_3;
        }
        double next_3_4 = dp_4_3 + rubble_4_3;
        if (onTheMap_4_2) {
            if (next_3_4 < dp_4_2) {
                dp_4_2 = next_3_4;
                dir_4_2 = dir_4_3;
            }
        }
        if (onTheMap_3_3) {
            if (next_3_4 < dp_3_3) {
                dp_3_3 = next_3_4;
                dir_3_3 = dir_4_3;
            }
        }
        if (onTheMap_5_2) {
            if (next_3_4 < dp_5_2) {
                dp_5_2 = next_3_4;
                dir_5_2 = dir_4_3;
            }
        }
        if (onTheMap_3_2) {
            dp_3_2 = next_3_4;
            dir_3_2 = dir_4_3;
        }
        double next_4_3 = dp_3_4 + rubble_3_4;
        if (onTheMap_3_3) {
            if (next_4_3 < dp_3_3) {
                dp_3_3 = next_4_3;
                dir_3_3 = dir_3_4;
            }
        }
        if (onTheMap_2_4) {
            if (next_4_3 < dp_2_4) {
                dp_2_4 = next_4_3;
                dir_2_4 = dir_3_4;
            }
        }
        if (onTheMap_2_3) {
            dp_2_3 = next_4_3;
            dir_2_3 = dir_3_4;
        }
        if (onTheMap_2_5) {
            if (next_4_3 < dp_2_5) {
                dp_2_5 = next_4_3;
                dir_2_5 = dir_3_4;
            }
        }
        double next_6_3 = dp_3_6 + rubble_3_6;
        if (onTheMap_3_7) {
            if (next_6_3 < dp_3_7) {
                dp_3_7 = next_6_3;
                dir_3_7 = dir_3_6;
            }
        }
        if (onTheMap_2_6) {
            if (next_6_3 < dp_2_6) {
                dp_2_6 = next_6_3;
                dir_2_6 = dir_3_6;
            }
        }
        if (onTheMap_2_5) {
            if (next_6_3 < dp_2_5) {
                dp_2_5 = next_6_3;
                dir_2_5 = dir_3_6;
            }
        }
        if (onTheMap_2_7) {
            dp_2_7 = next_6_3;
            dir_2_7 = dir_3_6;
        }
        double next_7_4 = dp_4_7 + rubble_4_7;
        if (onTheMap_4_8) {
            if (next_7_4 < dp_4_8) {
                dp_4_8 = next_7_4;
                dir_4_8 = dir_4_7;
            }
        }
        if (onTheMap_3_7) {
            if (next_7_4 < dp_3_7) {
                dp_3_7 = next_7_4;
                dir_3_7 = dir_4_7;
            }
        }
        if (onTheMap_5_8) {
            if (next_7_4 < dp_5_8) {
                dp_5_8 = next_7_4;
                dir_5_8 = dir_4_7;
            }
        }
        if (onTheMap_3_8) {
            dp_3_8 = next_7_4;
            dir_3_8 = dir_4_7;
        }
        double next_7_6 = dp_6_7 + rubble_6_7;
        if (onTheMap_6_8) {
            if (next_7_6 < dp_6_8) {
                dp_6_8 = next_7_6;
                dir_6_8 = dir_6_7;
            }
        }
        if (onTheMap_7_7) {
            if (next_7_6 < dp_7_7) {
                dp_7_7 = next_7_6;
                dir_7_7 = dir_6_7;
            }
        }
        if (onTheMap_7_8) {
            dp_7_8 = next_7_6;
            dir_7_8 = dir_6_7;
        }
        if (onTheMap_5_8) {
            if (next_7_6 < dp_5_8) {
                dp_5_8 = next_7_6;
                dir_5_8 = dir_6_7;
            }
        }
        double next_6_7 = dp_7_6 + rubble_7_6;
        if (onTheMap_7_7) {
            if (next_6_7 < dp_7_7) {
                dp_7_7 = next_6_7;
                dir_7_7 = dir_7_6;
            }
        }
        if (onTheMap_8_6) {
            if (next_6_7 < dp_8_6) {
                dp_8_6 = next_6_7;
                dir_8_6 = dir_7_6;
            }
        }
        if (onTheMap_8_7) {
            dp_8_7 = next_6_7;
            dir_8_7 = dir_7_6;
        }
        if (onTheMap_8_5) {
            if (next_6_7 < dp_8_5) {
                dp_8_5 = next_6_7;
                dir_8_5 = dir_7_6;
            }
        }
        double next_4_7 = dp_7_4 + rubble_7_4;
        if (onTheMap_8_4) {
            if (next_4_7 < dp_8_4) {
                dp_8_4 = next_4_7;
                dir_8_4 = dir_7_4;
            }
        }
        if (onTheMap_7_3) {
            if (next_4_7 < dp_7_3) {
                dp_7_3 = next_4_7;
                dir_7_3 = dir_7_4;
            }
        }
        if (onTheMap_8_5) {
            if (next_4_7 < dp_8_5) {
                dp_8_5 = next_4_7;
                dir_8_5 = dir_7_4;
            }
        }
        if (onTheMap_8_3) {
            dp_8_3 = next_4_7;
            dir_8_3 = dir_7_4;
        }
        double next_3_6 = dp_6_3 + rubble_6_3;
        if (onTheMap_7_3) {
            if (next_3_6 < dp_7_3) {
                dp_7_3 = next_3_6;
                dir_7_3 = dir_6_3;
            }
        }
        if (onTheMap_6_2) {
            if (next_3_6 < dp_6_2) {
                dp_6_2 = next_3_6;
                dir_6_2 = dir_6_3;
            }
        }
        if (onTheMap_7_2) {
            dp_7_2 = next_3_6;
            dir_7_2 = dir_6_3;
        }
        if (onTheMap_5_2) {
            if (next_3_6 < dp_5_2) {
                dp_5_2 = next_3_6;
                dir_5_2 = dir_6_3;
            }
        }
        double next_3_3 = dp_3_3 + rubble_3_3;
        if (onTheMap_3_2) {
            if (next_3_3 < dp_3_2) {
                dp_3_2 = next_3_3;
                dir_3_2 = dir_3_3;
            }
        }
        if (onTheMap_2_3) {
            if (next_3_3 < dp_2_3) {
                dp_2_3 = next_3_3;
                dir_2_3 = dir_3_3;
            }
        }
        if (onTheMap_4_2) {
            if (next_3_3 < dp_4_2) {
                dp_4_2 = next_3_3;
                dir_4_2 = dir_3_3;
            }
        }
        if (onTheMap_2_2) {
            dp_2_2 = next_3_3;
            dir_2_2 = dir_3_3;
        }
        if (onTheMap_2_4) {
            if (next_3_3 < dp_2_4) {
                dp_2_4 = next_3_3;
                dir_2_4 = dir_3_3;
            }
        }
        double next_7_3 = dp_3_7 + rubble_3_7;
        if (onTheMap_3_8) {
            if (next_7_3 < dp_3_8) {
                dp_3_8 = next_7_3;
                dir_3_8 = dir_3_7;
            }
        }
        if (onTheMap_2_7) {
            if (next_7_3 < dp_2_7) {
                dp_2_7 = next_7_3;
                dir_2_7 = dir_3_7;
            }
        }
        if (onTheMap_4_8) {
            if (next_7_3 < dp_4_8) {
                dp_4_8 = next_7_3;
                dir_4_8 = dir_3_7;
            }
        }
        if (onTheMap_2_6) {
            if (next_7_3 < dp_2_6) {
                dp_2_6 = next_7_3;
                dir_2_6 = dir_3_7;
            }
        }
        if (onTheMap_2_8) {
            dp_2_8 = next_7_3;
            dir_2_8 = dir_3_7;
        }
        double next_7_7 = dp_7_7 + rubble_7_7;
        if (onTheMap_7_8) {
            if (next_7_7 < dp_7_8) {
                dp_7_8 = next_7_7;
                dir_7_8 = dir_7_7;
            }
        }
        if (onTheMap_8_7) {
            if (next_7_7 < dp_8_7) {
                dp_8_7 = next_7_7;
                dir_8_7 = dir_7_7;
            }
        }
        if (onTheMap_8_8) {
            dp_8_8 = next_7_7;
            dir_8_8 = dir_7_7;
        }
        if (onTheMap_8_6) {
            if (next_7_7 < dp_8_6) {
                dp_8_6 = next_7_7;
                dir_8_6 = dir_7_7;
            }
        }
        if (onTheMap_6_8) {
            if (next_7_7 < dp_6_8) {
                dp_6_8 = next_7_7;
                dir_6_8 = dir_7_7;
            }
        }
        double next_3_7 = dp_7_3 + rubble_7_3;
        if (onTheMap_8_3) {
            if (next_3_7 < dp_8_3) {
                dp_8_3 = next_3_7;
                dir_8_3 = dir_7_3;
            }
        }
        if (onTheMap_7_2) {
            if (next_3_7 < dp_7_2) {
                dp_7_2 = next_3_7;
                dir_7_2 = dir_7_3;
            }
        }
        if (onTheMap_8_4) {
            if (next_3_7 < dp_8_4) {
                dp_8_4 = next_3_7;
                dir_8_4 = dir_7_3;
            }
        }
        if (onTheMap_8_2) {
            dp_8_2 = next_3_7;
            dir_8_2 = dir_7_3;
        }
        if (onTheMap_6_2) {
            if (next_3_7 < dp_6_2) {
                dp_6_2 = next_3_7;
                dir_6_2 = dir_7_3;
            }
        }
        double next_5_2 = dp_2_5 + rubble_2_5;
        if (onTheMap_2_6) {
            if (next_5_2 < dp_2_6) {
                dp_2_6 = next_5_2;
                dir_2_6 = dir_2_5;
            }
        }
        if (onTheMap_2_4) {
            if (next_5_2 < dp_2_4) {
                dp_2_4 = next_5_2;
                dir_2_4 = dir_2_5;
            }
        }
        if (onTheMap_1_5) {
            dp_1_5 = next_5_2;
            dir_1_5 = dir_2_5;
        }
        if (onTheMap_1_4) {
            dp_1_4 = next_5_2;
            dir_1_4 = dir_2_5;
        }
        if (onTheMap_1_6) {
            dp_1_6 = next_5_2;
            dir_1_6 = dir_2_5;
        }
        double next_8_5 = dp_5_8 + rubble_5_8;
        if (onTheMap_5_9) {
            dp_5_9 = next_8_5;
            dir_5_9 = dir_5_8;
        }
        if (onTheMap_6_8) {
            if (next_8_5 < dp_6_8) {
                dp_6_8 = next_8_5;
                dir_6_8 = dir_5_8;
            }
        }
        if (onTheMap_4_8) {
            if (next_8_5 < dp_4_8) {
                dp_4_8 = next_8_5;
                dir_4_8 = dir_5_8;
            }
        }
        if (onTheMap_6_9) {
            dp_6_9 = next_8_5;
            dir_6_9 = dir_5_8;
        }
        if (onTheMap_4_9) {
            dp_4_9 = next_8_5;
            dir_4_9 = dir_5_8;
        }
        double next_5_8 = dp_8_5 + rubble_8_5;
        if (onTheMap_8_6) {
            if (next_5_8 < dp_8_6) {
                dp_8_6 = next_5_8;
                dir_8_6 = dir_8_5;
            }
        }
        if (onTheMap_9_5) {
            dp_9_5 = next_5_8;
            dir_9_5 = dir_8_5;
        }
        if (onTheMap_8_4) {
            if (next_5_8 < dp_8_4) {
                dp_8_4 = next_5_8;
                dir_8_4 = dir_8_5;
            }
        }
        if (onTheMap_9_6) {
            dp_9_6 = next_5_8;
            dir_9_6 = dir_8_5;
        }
        if (onTheMap_9_4) {
            dp_9_4 = next_5_8;
            dir_9_4 = dir_8_5;
        }
        double next_2_5 = dp_5_2 + rubble_5_2;
        if (onTheMap_6_2) {
            if (next_2_5 < dp_6_2) {
                dp_6_2 = next_2_5;
                dir_6_2 = dir_5_2;
            }
        }
        if (onTheMap_5_1) {
            dp_5_1 = next_2_5;
            dir_5_1 = dir_5_2;
        }
        if (onTheMap_4_2) {
            if (next_2_5 < dp_4_2) {
                dp_4_2 = next_2_5;
                dir_4_2 = dir_5_2;
            }
        }
        if (onTheMap_6_1) {
            dp_6_1 = next_2_5;
            dir_6_1 = dir_5_2;
        }
        if (onTheMap_4_1) {
            dp_4_1 = next_2_5;
            dir_4_1 = dir_5_2;
        }
        double next_2_4 = dp_4_2 + rubble_4_2;
        if (onTheMap_4_1) {
            if (next_2_4 < dp_4_1) {
                dp_4_1 = next_2_4;
                dir_4_1 = dir_4_2;
            }
        }
        if (onTheMap_3_2) {
            if (next_2_4 < dp_3_2) {
                dp_3_2 = next_2_4;
                dir_3_2 = dir_4_2;
            }
        }
        if (onTheMap_5_1) {
            if (next_2_4 < dp_5_1) {
                dp_5_1 = next_2_4;
                dir_5_1 = dir_4_2;
            }
        }
        if (onTheMap_3_1) {
            dp_3_1 = next_2_4;
            dir_3_1 = dir_4_2;
        }
        double next_4_2 = dp_2_4 + rubble_2_4;
        if (onTheMap_2_3) {
            if (next_4_2 < dp_2_3) {
                dp_2_3 = next_4_2;
                dir_2_3 = dir_2_4;
            }
        }
        if (onTheMap_1_4) {
            if (next_4_2 < dp_1_4) {
                dp_1_4 = next_4_2;
                dir_1_4 = dir_2_4;
            }
        }
        if (onTheMap_1_3) {
            dp_1_3 = next_4_2;
            dir_1_3 = dir_2_4;
        }
        if (onTheMap_1_5) {
            if (next_4_2 < dp_1_5) {
                dp_1_5 = next_4_2;
                dir_1_5 = dir_2_4;
            }
        }
        double next_6_2 = dp_2_6 + rubble_2_6;
        if (onTheMap_2_7) {
            if (next_6_2 < dp_2_7) {
                dp_2_7 = next_6_2;
                dir_2_7 = dir_2_6;
            }
        }
        if (onTheMap_1_6) {
            if (next_6_2 < dp_1_6) {
                dp_1_6 = next_6_2;
                dir_1_6 = dir_2_6;
            }
        }
        if (onTheMap_1_5) {
            if (next_6_2 < dp_1_5) {
                dp_1_5 = next_6_2;
                dir_1_5 = dir_2_6;
            }
        }
        if (onTheMap_1_7) {
            dp_1_7 = next_6_2;
            dir_1_7 = dir_2_6;
        }
        double next_8_4 = dp_4_8 + rubble_4_8;
        if (onTheMap_4_9) {
            if (next_8_4 < dp_4_9) {
                dp_4_9 = next_8_4;
                dir_4_9 = dir_4_8;
            }
        }
        if (onTheMap_3_8) {
            if (next_8_4 < dp_3_8) {
                dp_3_8 = next_8_4;
                dir_3_8 = dir_4_8;
            }
        }
        if (onTheMap_5_9) {
            if (next_8_4 < dp_5_9) {
                dp_5_9 = next_8_4;
                dir_5_9 = dir_4_8;
            }
        }
        if (onTheMap_3_9) {
            dp_3_9 = next_8_4;
            dir_3_9 = dir_4_8;
        }
        double next_8_6 = dp_6_8 + rubble_6_8;
        if (onTheMap_6_9) {
            if (next_8_6 < dp_6_9) {
                dp_6_9 = next_8_6;
                dir_6_9 = dir_6_8;
            }
        }
        if (onTheMap_7_8) {
            if (next_8_6 < dp_7_8) {
                dp_7_8 = next_8_6;
                dir_7_8 = dir_6_8;
            }
        }
        if (onTheMap_7_9) {
            dp_7_9 = next_8_6;
            dir_7_9 = dir_6_8;
        }
        if (onTheMap_5_9) {
            if (next_8_6 < dp_5_9) {
                dp_5_9 = next_8_6;
                dir_5_9 = dir_6_8;
            }
        }
        double next_6_8 = dp_8_6 + rubble_8_6;
        if (onTheMap_8_7) {
            if (next_6_8 < dp_8_7) {
                dp_8_7 = next_6_8;
                dir_8_7 = dir_8_6;
            }
        }
        if (onTheMap_9_6) {
            if (next_6_8 < dp_9_6) {
                dp_9_6 = next_6_8;
                dir_9_6 = dir_8_6;
            }
        }
        if (onTheMap_9_7) {
            dp_9_7 = next_6_8;
            dir_9_7 = dir_8_6;
        }
        if (onTheMap_9_5) {
            if (next_6_8 < dp_9_5) {
                dp_9_5 = next_6_8;
                dir_9_5 = dir_8_6;
            }
        }
        double next_4_8 = dp_8_4 + rubble_8_4;
        if (onTheMap_9_4) {
            if (next_4_8 < dp_9_4) {
                dp_9_4 = next_4_8;
                dir_9_4 = dir_8_4;
            }
        }
        if (onTheMap_8_3) {
            if (next_4_8 < dp_8_3) {
                dp_8_3 = next_4_8;
                dir_8_3 = dir_8_4;
            }
        }
        if (onTheMap_9_5) {
            if (next_4_8 < dp_9_5) {
                dp_9_5 = next_4_8;
                dir_9_5 = dir_8_4;
            }
        }
        if (onTheMap_9_3) {
            dp_9_3 = next_4_8;
            dir_9_3 = dir_8_4;
        }
        double next_2_6 = dp_6_2 + rubble_6_2;
        if (onTheMap_7_2) {
            if (next_2_6 < dp_7_2) {
                dp_7_2 = next_2_6;
                dir_7_2 = dir_6_2;
            }
        }
        if (onTheMap_6_1) {
            if (next_2_6 < dp_6_1) {
                dp_6_1 = next_2_6;
                dir_6_1 = dir_6_2;
            }
        }
        if (onTheMap_7_1) {
            dp_7_1 = next_2_6;
            dir_7_1 = dir_6_2;
        }
        if (onTheMap_5_1) {
            if (next_2_6 < dp_5_1) {
                dp_5_1 = next_2_6;
                dir_5_1 = dir_6_2;
            }
        }
        double next_2_3 = dp_3_2 + rubble_3_2;
        if (onTheMap_3_1) {
            if (next_2_3 < dp_3_1) {
                dp_3_1 = next_2_3;
                dir_3_1 = dir_3_2;
            }
        }
        if (onTheMap_2_2) {
            if (next_2_3 < dp_2_2) {
                dp_2_2 = next_2_3;
                dir_2_2 = dir_3_2;
            }
        }
        if (onTheMap_4_1) {
            if (next_2_3 < dp_4_1) {
                dp_4_1 = next_2_3;
                dir_4_1 = dir_3_2;
            }
        }
        if (onTheMap_2_1) {
            dp_2_1 = next_2_3;
            dir_2_1 = dir_3_2;
        }
        double next_3_2 = dp_2_3 + rubble_2_3;
        if (onTheMap_2_2) {
            if (next_3_2 < dp_2_2) {
                dp_2_2 = next_3_2;
                dir_2_2 = dir_2_3;
            }
        }
        if (onTheMap_1_3) {
            if (next_3_2 < dp_1_3) {
                dp_1_3 = next_3_2;
                dir_1_3 = dir_2_3;
            }
        }
        if (onTheMap_1_2) {
            dp_1_2 = next_3_2;
            dir_1_2 = dir_2_3;
        }
        if (onTheMap_1_4) {
            if (next_3_2 < dp_1_4) {
                dp_1_4 = next_3_2;
                dir_1_4 = dir_2_3;
            }
        }
        double next_7_2 = dp_2_7 + rubble_2_7;
        if (onTheMap_2_8) {
            if (next_7_2 < dp_2_8) {
                dp_2_8 = next_7_2;
                dir_2_8 = dir_2_7;
            }
        }
        if (onTheMap_1_7) {
            if (next_7_2 < dp_1_7) {
                dp_1_7 = next_7_2;
                dir_1_7 = dir_2_7;
            }
        }
        if (onTheMap_1_6) {
            if (next_7_2 < dp_1_6) {
                dp_1_6 = next_7_2;
                dir_1_6 = dir_2_7;
            }
        }
        if (onTheMap_1_8) {
            dp_1_8 = next_7_2;
            dir_1_8 = dir_2_7;
        }
        double next_8_3 = dp_3_8 + rubble_3_8;
        if (onTheMap_3_9) {
            if (next_8_3 < dp_3_9) {
                dp_3_9 = next_8_3;
                dir_3_9 = dir_3_8;
            }
        }
        if (onTheMap_2_8) {
            if (next_8_3 < dp_2_8) {
                dp_2_8 = next_8_3;
                dir_2_8 = dir_3_8;
            }
        }
        if (onTheMap_4_9) {
            if (next_8_3 < dp_4_9) {
                dp_4_9 = next_8_3;
                dir_4_9 = dir_3_8;
            }
        }
        if (onTheMap_2_9) {
            dp_2_9 = next_8_3;
            dir_2_9 = dir_3_8;
        }
        double next_8_7 = dp_7_8 + rubble_7_8;
        if (onTheMap_7_9) {
            if (next_8_7 < dp_7_9) {
                dp_7_9 = next_8_7;
                dir_7_9 = dir_7_8;
            }
        }
        if (onTheMap_8_8) {
            if (next_8_7 < dp_8_8) {
                dp_8_8 = next_8_7;
                dir_8_8 = dir_7_8;
            }
        }
        if (onTheMap_8_9) {
            dp_8_9 = next_8_7;
            dir_8_9 = dir_7_8;
        }
        if (onTheMap_6_9) {
            if (next_8_7 < dp_6_9) {
                dp_6_9 = next_8_7;
                dir_6_9 = dir_7_8;
            }
        }
        double next_7_8 = dp_8_7 + rubble_8_7;
        if (onTheMap_8_8) {
            if (next_7_8 < dp_8_8) {
                dp_8_8 = next_7_8;
                dir_8_8 = dir_8_7;
            }
        }
        if (onTheMap_9_7) {
            if (next_7_8 < dp_9_7) {
                dp_9_7 = next_7_8;
                dir_9_7 = dir_8_7;
            }
        }
        if (onTheMap_9_8) {
            dp_9_8 = next_7_8;
            dir_9_8 = dir_8_7;
        }
        if (onTheMap_9_6) {
            if (next_7_8 < dp_9_6) {
                dp_9_6 = next_7_8;
                dir_9_6 = dir_8_7;
            }
        }
        double next_3_8 = dp_8_3 + rubble_8_3;
        if (onTheMap_9_3) {
            if (next_3_8 < dp_9_3) {
                dp_9_3 = next_3_8;
                dir_9_3 = dir_8_3;
            }
        }
        if (onTheMap_8_2) {
            if (next_3_8 < dp_8_2) {
                dp_8_2 = next_3_8;
                dir_8_2 = dir_8_3;
            }
        }
        if (onTheMap_9_4) {
            if (next_3_8 < dp_9_4) {
                dp_9_4 = next_3_8;
                dir_9_4 = dir_8_3;
            }
        }
        if (onTheMap_9_2) {
            dp_9_2 = next_3_8;
            dir_9_2 = dir_8_3;
        }
        double next_2_7 = dp_7_2 + rubble_7_2;
        if (onTheMap_8_2) {
            if (next_2_7 < dp_8_2) {
                dp_8_2 = next_2_7;
                dir_8_2 = dir_7_2;
            }
        }
        if (onTheMap_7_1) {
            if (next_2_7 < dp_7_1) {
                dp_7_1 = next_2_7;
                dir_7_1 = dir_7_2;
            }
        }
        if (onTheMap_8_1) {
            dp_8_1 = next_2_7;
            dir_8_1 = dir_7_2;
        }
        if (onTheMap_6_1) {
            if (next_2_7 < dp_6_1) {
                dp_6_1 = next_2_7;
                dir_6_1 = dir_7_2;
            }
        }
        double next_5_1 = dp_1_5 + rubble_1_5;
        if (onTheMap_1_6) {
            if (next_5_1 < dp_1_6) {
                dp_1_6 = next_5_1;
                dir_1_6 = dir_1_5;
            }
        }
        if (onTheMap_1_4) {
            if (next_5_1 < dp_1_4) {
                dp_1_4 = next_5_1;
                dir_1_4 = dir_1_5;
            }
        }
        if (onTheMap_0_5) {
            dp_0_5 = next_5_1;
            dir_0_5 = dir_1_5;
        }
        if (onTheMap_0_4) {
            dp_0_4 = next_5_1;
            dir_0_4 = dir_1_5;
        }
        if (onTheMap_0_6) {
            dp_0_6 = next_5_1;
            dir_0_6 = dir_1_5;
        }
        double next_9_5 = dp_5_9 + rubble_5_9;
        if (onTheMap_5_10) {
            dp_5_10 = next_9_5;
            dir_5_10 = dir_5_9;
        }
        if (onTheMap_6_9) {
            if (next_9_5 < dp_6_9) {
                dp_6_9 = next_9_5;
                dir_6_9 = dir_5_9;
            }
        }
        if (onTheMap_4_9) {
            if (next_9_5 < dp_4_9) {
                dp_4_9 = next_9_5;
                dir_4_9 = dir_5_9;
            }
        }
        if (onTheMap_6_10) {
            dp_6_10 = next_9_5;
            dir_6_10 = dir_5_9;
        }
        if (onTheMap_4_10) {
            dp_4_10 = next_9_5;
            dir_4_10 = dir_5_9;
        }
        double next_5_9 = dp_9_5 + rubble_9_5;
        if (onTheMap_9_6) {
            if (next_5_9 < dp_9_6) {
                dp_9_6 = next_5_9;
                dir_9_6 = dir_9_5;
            }
        }
        if (onTheMap_10_5) {
            dp_10_5 = next_5_9;
            dir_10_5 = dir_9_5;
        }
        if (onTheMap_9_4) {
            if (next_5_9 < dp_9_4) {
                dp_9_4 = next_5_9;
                dir_9_4 = dir_9_5;
            }
        }
        if (onTheMap_10_6) {
            dp_10_6 = next_5_9;
            dir_10_6 = dir_9_5;
        }
        if (onTheMap_10_4) {
            dp_10_4 = next_5_9;
            dir_10_4 = dir_9_5;
        }
        double next_1_5 = dp_5_1 + rubble_5_1;
        if (onTheMap_6_1) {
            if (next_1_5 < dp_6_1) {
                dp_6_1 = next_1_5;
                dir_6_1 = dir_5_1;
            }
        }
        if (onTheMap_5_0) {
            dp_5_0 = next_1_5;
            dir_5_0 = dir_5_1;
        }
        if (onTheMap_4_1) {
            if (next_1_5 < dp_4_1) {
                dp_4_1 = next_1_5;
                dir_4_1 = dir_5_1;
            }
        }
        if (onTheMap_6_0) {
            dp_6_0 = next_1_5;
            dir_6_0 = dir_5_1;
        }
        if (onTheMap_4_0) {
            dp_4_0 = next_1_5;
            dir_4_0 = dir_5_1;
        }
        double next_1_4 = dp_4_1 + rubble_4_1;
        if (onTheMap_4_0) {
            if (next_1_4 < dp_4_0) {
                dp_4_0 = next_1_4;
                dir_4_0 = dir_4_1;
            }
        }
        if (onTheMap_3_1) {
            if (next_1_4 < dp_3_1) {
                dp_3_1 = next_1_4;
                dir_3_1 = dir_4_1;
            }
        }
        if (onTheMap_5_0) {
            if (next_1_4 < dp_5_0) {
                dp_5_0 = next_1_4;
                dir_5_0 = dir_4_1;
            }
        }
        if (onTheMap_3_0) {
            dp_3_0 = next_1_4;
            dir_3_0 = dir_4_1;
        }
        double next_4_1 = dp_1_4 + rubble_1_4;
        if (onTheMap_1_3) {
            if (next_4_1 < dp_1_3) {
                dp_1_3 = next_4_1;
                dir_1_3 = dir_1_4;
            }
        }
        if (onTheMap_0_4) {
            if (next_4_1 < dp_0_4) {
                dp_0_4 = next_4_1;
                dir_0_4 = dir_1_4;
            }
        }
        if (onTheMap_0_3) {
            dp_0_3 = next_4_1;
            dir_0_3 = dir_1_4;
        }
        if (onTheMap_0_5) {
            if (next_4_1 < dp_0_5) {
                dp_0_5 = next_4_1;
                dir_0_5 = dir_1_4;
            }
        }
        double next_6_1 = dp_1_6 + rubble_1_6;
        if (onTheMap_1_7) {
            if (next_6_1 < dp_1_7) {
                dp_1_7 = next_6_1;
                dir_1_7 = dir_1_6;
            }
        }
        if (onTheMap_0_6) {
            if (next_6_1 < dp_0_6) {
                dp_0_6 = next_6_1;
                dir_0_6 = dir_1_6;
            }
        }
        if (onTheMap_0_5) {
            if (next_6_1 < dp_0_5) {
                dp_0_5 = next_6_1;
                dir_0_5 = dir_1_6;
            }
        }
        if (onTheMap_0_7) {
            dp_0_7 = next_6_1;
            dir_0_7 = dir_1_6;
        }
        double next_9_4 = dp_4_9 + rubble_4_9;
        if (onTheMap_4_10) {
            if (next_9_4 < dp_4_10) {
                dp_4_10 = next_9_4;
                dir_4_10 = dir_4_9;
            }
        }
        if (onTheMap_3_9) {
            if (next_9_4 < dp_3_9) {
                dp_3_9 = next_9_4;
                dir_3_9 = dir_4_9;
            }
        }
        if (onTheMap_5_10) {
            if (next_9_4 < dp_5_10) {
                dp_5_10 = next_9_4;
                dir_5_10 = dir_4_9;
            }
        }
        if (onTheMap_3_10) {
            dp_3_10 = next_9_4;
            dir_3_10 = dir_4_9;
        }
        double next_9_6 = dp_6_9 + rubble_6_9;
        if (onTheMap_6_10) {
            if (next_9_6 < dp_6_10) {
                dp_6_10 = next_9_6;
                dir_6_10 = dir_6_9;
            }
        }
        if (onTheMap_7_9) {
            if (next_9_6 < dp_7_9) {
                dp_7_9 = next_9_6;
                dir_7_9 = dir_6_9;
            }
        }
        if (onTheMap_7_10) {
            dp_7_10 = next_9_6;
            dir_7_10 = dir_6_9;
        }
        if (onTheMap_5_10) {
            if (next_9_6 < dp_5_10) {
                dp_5_10 = next_9_6;
                dir_5_10 = dir_6_9;
            }
        }
        double next_6_9 = dp_9_6 + rubble_9_6;
        if (onTheMap_9_7) {
            if (next_6_9 < dp_9_7) {
                dp_9_7 = next_6_9;
                dir_9_7 = dir_9_6;
            }
        }
        if (onTheMap_10_6) {
            if (next_6_9 < dp_10_6) {
                dp_10_6 = next_6_9;
                dir_10_6 = dir_9_6;
            }
        }
        if (onTheMap_10_7) {
            dp_10_7 = next_6_9;
            dir_10_7 = dir_9_6;
        }
        if (onTheMap_10_5) {
            if (next_6_9 < dp_10_5) {
                dp_10_5 = next_6_9;
                dir_10_5 = dir_9_6;
            }
        }
        double next_4_9 = dp_9_4 + rubble_9_4;
        if (onTheMap_10_4) {
            if (next_4_9 < dp_10_4) {
                dp_10_4 = next_4_9;
                dir_10_4 = dir_9_4;
            }
        }
        if (onTheMap_9_3) {
            if (next_4_9 < dp_9_3) {
                dp_9_3 = next_4_9;
                dir_9_3 = dir_9_4;
            }
        }
        if (onTheMap_10_5) {
            if (next_4_9 < dp_10_5) {
                dp_10_5 = next_4_9;
                dir_10_5 = dir_9_4;
            }
        }
        if (onTheMap_10_3) {
            dp_10_3 = next_4_9;
            dir_10_3 = dir_9_4;
        }
        double next_1_6 = dp_6_1 + rubble_6_1;
        if (onTheMap_7_1) {
            if (next_1_6 < dp_7_1) {
                dp_7_1 = next_1_6;
                dir_7_1 = dir_6_1;
            }
        }
        if (onTheMap_6_0) {
            if (next_1_6 < dp_6_0) {
                dp_6_0 = next_1_6;
                dir_6_0 = dir_6_1;
            }
        }
        if (onTheMap_7_0) {
            dp_7_0 = next_1_6;
            dir_7_0 = dir_6_1;
        }
        if (onTheMap_5_0) {
            if (next_1_6 < dp_5_0) {
                dp_5_0 = next_1_6;
                dir_5_0 = dir_6_1;
            }
        }
        double next_2_2 = dp_2_2 + rubble_2_2;
        if (onTheMap_2_1) {
            if (next_2_2 < dp_2_1) {
                dp_2_1 = next_2_2;
                dir_2_1 = dir_2_2;
            }
        }
        if (onTheMap_1_2) {
            if (next_2_2 < dp_1_2) {
                dp_1_2 = next_2_2;
                dir_1_2 = dir_2_2;
            }
        }
        if (onTheMap_3_1) {
            if (next_2_2 < dp_3_1) {
                dp_3_1 = next_2_2;
                dir_3_1 = dir_2_2;
            }
        }
        if (onTheMap_1_1) {
            dp_1_1 = next_2_2;
            dir_1_1 = dir_2_2;
        }
        if (onTheMap_1_3) {
            if (next_2_2 < dp_1_3) {
                dp_1_3 = next_2_2;
                dir_1_3 = dir_2_2;
            }
        }
        double next_8_2 = dp_2_8 + rubble_2_8;
        if (onTheMap_2_9) {
            if (next_8_2 < dp_2_9) {
                dp_2_9 = next_8_2;
                dir_2_9 = dir_2_8;
            }
        }
        if (onTheMap_1_8) {
            if (next_8_2 < dp_1_8) {
                dp_1_8 = next_8_2;
                dir_1_8 = dir_2_8;
            }
        }
        if (onTheMap_3_9) {
            if (next_8_2 < dp_3_9) {
                dp_3_9 = next_8_2;
                dir_3_9 = dir_2_8;
            }
        }
        if (onTheMap_1_7) {
            if (next_8_2 < dp_1_7) {
                dp_1_7 = next_8_2;
                dir_1_7 = dir_2_8;
            }
        }
        if (onTheMap_1_9) {
            dp_1_9 = next_8_2;
            dir_1_9 = dir_2_8;
        }
        double next_8_8 = dp_8_8 + rubble_8_8;
        if (onTheMap_8_9) {
            if (next_8_8 < dp_8_9) {
                dp_8_9 = next_8_8;
                dir_8_9 = dir_8_8;
            }
        }
        if (onTheMap_9_8) {
            if (next_8_8 < dp_9_8) {
                dp_9_8 = next_8_8;
                dir_9_8 = dir_8_8;
            }
        }
        if (onTheMap_9_9) {
            dp_9_9 = next_8_8;
            dir_9_9 = dir_8_8;
        }
        if (onTheMap_9_7) {
            if (next_8_8 < dp_9_7) {
                dp_9_7 = next_8_8;
                dir_9_7 = dir_8_8;
            }
        }
        if (onTheMap_7_9) {
            if (next_8_8 < dp_7_9) {
                dp_7_9 = next_8_8;
                dir_7_9 = dir_8_8;
            }
        }
        double next_2_8 = dp_8_2 + rubble_8_2;
        if (onTheMap_9_2) {
            if (next_2_8 < dp_9_2) {
                dp_9_2 = next_2_8;
                dir_9_2 = dir_8_2;
            }
        }
        if (onTheMap_8_1) {
            if (next_2_8 < dp_8_1) {
                dp_8_1 = next_2_8;
                dir_8_1 = dir_8_2;
            }
        }
        if (onTheMap_9_3) {
            if (next_2_8 < dp_9_3) {
                dp_9_3 = next_2_8;
                dir_9_3 = dir_8_2;
            }
        }
        if (onTheMap_9_1) {
            dp_9_1 = next_2_8;
            dir_9_1 = dir_8_2;
        }
        if (onTheMap_7_1) {
            if (next_2_8 < dp_7_1) {
                dp_7_1 = next_2_8;
                dir_7_1 = dir_8_2;
            }
        }
        double next_1_3 = dp_3_1 + rubble_3_1;
        if (onTheMap_3_0) {
            if (next_1_3 < dp_3_0) {
                dp_3_0 = next_1_3;
                dir_3_0 = dir_3_1;
            }
        }
        if (onTheMap_2_1) {
            if (next_1_3 < dp_2_1) {
                dp_2_1 = next_1_3;
                dir_2_1 = dir_3_1;
            }
        }
        if (onTheMap_4_0) {
            if (next_1_3 < dp_4_0) {
                dp_4_0 = next_1_3;
                dir_4_0 = dir_3_1;
            }
        }
        if (onTheMap_2_0) {
            dp_2_0 = next_1_3;
            dir_2_0 = dir_3_1;
        }
        double next_3_1 = dp_1_3 + rubble_1_3;
        if (onTheMap_1_2) {
            if (next_3_1 < dp_1_2) {
                dp_1_2 = next_3_1;
                dir_1_2 = dir_1_3;
            }
        }
        if (onTheMap_0_3) {
            if (next_3_1 < dp_0_3) {
                dp_0_3 = next_3_1;
                dir_0_3 = dir_1_3;
            }
        }
        if (onTheMap_0_2) {
            dp_0_2 = next_3_1;
            dir_0_2 = dir_1_3;
        }
        if (onTheMap_0_4) {
            if (next_3_1 < dp_0_4) {
                dp_0_4 = next_3_1;
                dir_0_4 = dir_1_3;
            }
        }
        double next_7_1 = dp_1_7 + rubble_1_7;
        if (onTheMap_1_8) {
            if (next_7_1 < dp_1_8) {
                dp_1_8 = next_7_1;
                dir_1_8 = dir_1_7;
            }
        }
        if (onTheMap_0_7) {
            if (next_7_1 < dp_0_7) {
                dp_0_7 = next_7_1;
                dir_0_7 = dir_1_7;
            }
        }
        if (onTheMap_0_6) {
            if (next_7_1 < dp_0_6) {
                dp_0_6 = next_7_1;
                dir_0_6 = dir_1_7;
            }
        }
        if (onTheMap_0_8) {
            dp_0_8 = next_7_1;
            dir_0_8 = dir_1_7;
        }
        double next_9_3 = dp_3_9 + rubble_3_9;
        if (onTheMap_3_10) {
            if (next_9_3 < dp_3_10) {
                dp_3_10 = next_9_3;
                dir_3_10 = dir_3_9;
            }
        }
        if (onTheMap_2_9) {
            if (next_9_3 < dp_2_9) {
                dp_2_9 = next_9_3;
                dir_2_9 = dir_3_9;
            }
        }
        if (onTheMap_4_10) {
            if (next_9_3 < dp_4_10) {
                dp_4_10 = next_9_3;
                dir_4_10 = dir_3_9;
            }
        }
        if (onTheMap_2_10) {
            dp_2_10 = next_9_3;
            dir_2_10 = dir_3_9;
        }
        double next_9_7 = dp_7_9 + rubble_7_9;
        if (onTheMap_7_10) {
            if (next_9_7 < dp_7_10) {
                dp_7_10 = next_9_7;
                dir_7_10 = dir_7_9;
            }
        }
        if (onTheMap_8_9) {
            if (next_9_7 < dp_8_9) {
                dp_8_9 = next_9_7;
                dir_8_9 = dir_7_9;
            }
        }
        if (onTheMap_8_10) {
            dp_8_10 = next_9_7;
            dir_8_10 = dir_7_9;
        }
        if (onTheMap_6_10) {
            if (next_9_7 < dp_6_10) {
                dp_6_10 = next_9_7;
                dir_6_10 = dir_7_9;
            }
        }
        double next_7_9 = dp_9_7 + rubble_9_7;
        if (onTheMap_9_8) {
            if (next_7_9 < dp_9_8) {
                dp_9_8 = next_7_9;
                dir_9_8 = dir_9_7;
            }
        }
        if (onTheMap_10_7) {
            if (next_7_9 < dp_10_7) {
                dp_10_7 = next_7_9;
                dir_10_7 = dir_9_7;
            }
        }
        if (onTheMap_10_8) {
            dp_10_8 = next_7_9;
            dir_10_8 = dir_9_7;
        }
        if (onTheMap_10_6) {
            if (next_7_9 < dp_10_6) {
                dp_10_6 = next_7_9;
                dir_10_6 = dir_9_7;
            }
        }
        double next_3_9 = dp_9_3 + rubble_9_3;
        if (onTheMap_10_3) {
            if (next_3_9 < dp_10_3) {
                dp_10_3 = next_3_9;
                dir_10_3 = dir_9_3;
            }
        }
        if (onTheMap_9_2) {
            if (next_3_9 < dp_9_2) {
                dp_9_2 = next_3_9;
                dir_9_2 = dir_9_3;
            }
        }
        if (onTheMap_10_4) {
            if (next_3_9 < dp_10_4) {
                dp_10_4 = next_3_9;
                dir_10_4 = dir_9_3;
            }
        }
        if (onTheMap_10_2) {
            dp_10_2 = next_3_9;
            dir_10_2 = dir_9_3;
        }
        double next_1_7 = dp_7_1 + rubble_7_1;
        if (onTheMap_8_1) {
            if (next_1_7 < dp_8_1) {
                dp_8_1 = next_1_7;
                dir_8_1 = dir_7_1;
            }
        }
        if (onTheMap_7_0) {
            if (next_1_7 < dp_7_0) {
                dp_7_0 = next_1_7;
                dir_7_0 = dir_7_1;
            }
        }
        if (onTheMap_8_0) {
            dp_8_0 = next_1_7;
            dir_8_0 = dir_7_1;
        }
        if (onTheMap_6_0) {
            if (next_1_7 < dp_6_0) {
                dp_6_0 = next_1_7;
                dir_6_0 = dir_7_1;
            }
        }
        double next_1_2 = dp_2_1 + rubble_2_1;
        if (onTheMap_2_0) {
            if (next_1_2 < dp_2_0) {
                dp_2_0 = next_1_2;
                dir_2_0 = dir_2_1;
            }
        }
        if (onTheMap_1_1) {
            if (next_1_2 < dp_1_1) {
                dp_1_1 = next_1_2;
                dir_1_1 = dir_2_1;
            }
        }
        if (onTheMap_3_0) {
            if (next_1_2 < dp_3_0) {
                dp_3_0 = next_1_2;
                dir_3_0 = dir_2_1;
            }
        }
        double next_2_1 = dp_1_2 + rubble_1_2;
        if (onTheMap_1_1) {
            if (next_2_1 < dp_1_1) {
                dp_1_1 = next_2_1;
                dir_1_1 = dir_1_2;
            }
        }
        if (onTheMap_0_2) {
            if (next_2_1 < dp_0_2) {
                dp_0_2 = next_2_1;
                dir_0_2 = dir_1_2;
            }
        }
        if (onTheMap_0_3) {
            if (next_2_1 < dp_0_3) {
                dp_0_3 = next_2_1;
                dir_0_3 = dir_1_2;
            }
        }
        double next_5_0 = dp_0_5 + rubble_0_5;
        if (onTheMap_0_6) {
            if (next_5_0 < dp_0_6) {
                dp_0_6 = next_5_0;
                dir_0_6 = dir_0_5;
            }
        }
        if (onTheMap_0_4) {
            if (next_5_0 < dp_0_4) {
                dp_0_4 = next_5_0;
                dir_0_4 = dir_0_5;
            }
        }
        double next_8_1 = dp_1_8 + rubble_1_8;
        if (onTheMap_1_9) {
            if (next_8_1 < dp_1_9) {
                dp_1_9 = next_8_1;
                dir_1_9 = dir_1_8;
            }
        }
        if (onTheMap_0_8) {
            if (next_8_1 < dp_0_8) {
                dp_0_8 = next_8_1;
                dir_0_8 = dir_1_8;
            }
        }
        if (onTheMap_0_7) {
            if (next_8_1 < dp_0_7) {
                dp_0_7 = next_8_1;
                dir_0_7 = dir_1_8;
            }
        }
        double next_9_2 = dp_2_9 + rubble_2_9;
        if (onTheMap_2_10) {
            if (next_9_2 < dp_2_10) {
                dp_2_10 = next_9_2;
                dir_2_10 = dir_2_9;
            }
        }
        if (onTheMap_1_9) {
            if (next_9_2 < dp_1_9) {
                dp_1_9 = next_9_2;
                dir_1_9 = dir_2_9;
            }
        }
        if (onTheMap_3_10) {
            if (next_9_2 < dp_3_10) {
                dp_3_10 = next_9_2;
                dir_3_10 = dir_2_9;
            }
        }
        double next_10_5 = dp_5_10 + rubble_5_10;
        if (onTheMap_6_10) {
            if (next_10_5 < dp_6_10) {
                dp_6_10 = next_10_5;
                dir_6_10 = dir_5_10;
            }
        }
        if (onTheMap_4_10) {
            if (next_10_5 < dp_4_10) {
                dp_4_10 = next_10_5;
                dir_4_10 = dir_5_10;
            }
        }
        double next_9_8 = dp_8_9 + rubble_8_9;
        if (onTheMap_8_10) {
            if (next_9_8 < dp_8_10) {
                dp_8_10 = next_9_8;
                dir_8_10 = dir_8_9;
            }
        }
        if (onTheMap_9_9) {
            if (next_9_8 < dp_9_9) {
                dp_9_9 = next_9_8;
                dir_9_9 = dir_8_9;
            }
        }
        if (onTheMap_7_10) {
            if (next_9_8 < dp_7_10) {
                dp_7_10 = next_9_8;
                dir_7_10 = dir_8_9;
            }
        }
        double next_8_9 = dp_9_8 + rubble_9_8;
        if (onTheMap_9_9) {
            if (next_8_9 < dp_9_9) {
                dp_9_9 = next_8_9;
                dir_9_9 = dir_9_8;
            }
        }
        if (onTheMap_10_8) {
            if (next_8_9 < dp_10_8) {
                dp_10_8 = next_8_9;
                dir_10_8 = dir_9_8;
            }
        }
        if (onTheMap_10_7) {
            if (next_8_9 < dp_10_7) {
                dp_10_7 = next_8_9;
                dir_10_7 = dir_9_8;
            }
        }
        double next_5_10 = dp_10_5 + rubble_10_5;
        if (onTheMap_10_6) {
            if (next_5_10 < dp_10_6) {
                dp_10_6 = next_5_10;
                dir_10_6 = dir_10_5;
            }
        }
        if (onTheMap_10_4) {
            if (next_5_10 < dp_10_4) {
                dp_10_4 = next_5_10;
                dir_10_4 = dir_10_5;
            }
        }
        double next_2_9 = dp_9_2 + rubble_9_2;
        if (onTheMap_10_2) {
            if (next_2_9 < dp_10_2) {
                dp_10_2 = next_2_9;
                dir_10_2 = dir_9_2;
            }
        }
        if (onTheMap_9_1) {
            if (next_2_9 < dp_9_1) {
                dp_9_1 = next_2_9;
                dir_9_1 = dir_9_2;
            }
        }
        if (onTheMap_10_3) {
            if (next_2_9 < dp_10_3) {
                dp_10_3 = next_2_9;
                dir_10_3 = dir_9_2;
            }
        }
        double next_1_8 = dp_8_1 + rubble_8_1;
        if (onTheMap_9_1) {
            if (next_1_8 < dp_9_1) {
                dp_9_1 = next_1_8;
                dir_9_1 = dir_8_1;
            }
        }
        if (onTheMap_8_0) {
            if (next_1_8 < dp_8_0) {
                dp_8_0 = next_1_8;
                dir_8_0 = dir_8_1;
            }
        }
        if (onTheMap_7_0) {
            if (next_1_8 < dp_7_0) {
                dp_7_0 = next_1_8;
                dir_7_0 = dir_8_1;
            }
        }
        double next_0_5 = dp_5_0 + rubble_5_0;
        if (onTheMap_6_0) {
            if (next_0_5 < dp_6_0) {
                dp_6_0 = next_0_5;
                dir_6_0 = dir_5_0;
            }
        }
        if (onTheMap_4_0) {
            if (next_0_5 < dp_4_0) {
                dp_4_0 = next_0_5;
                dir_4_0 = dir_5_0;
            }
        }
        double next_0_4 = dp_4_0 + rubble_4_0;
        if (onTheMap_3_0) {
            if (next_0_4 < dp_3_0) {
                dp_3_0 = next_0_4;
                dir_3_0 = dir_4_0;
            }
        }
        double next_4_0 = dp_0_4 + rubble_0_4;
        if (onTheMap_0_3) {
            if (next_4_0 < dp_0_3) {
                dp_0_3 = next_4_0;
                dir_0_3 = dir_0_4;
            }
        }
        double next_6_0 = dp_0_6 + rubble_0_6;
        if (onTheMap_0_7) {
            if (next_6_0 < dp_0_7) {
                dp_0_7 = next_6_0;
                dir_0_7 = dir_0_6;
            }
        }
        double next_10_4 = dp_4_10 + rubble_4_10;
        if (onTheMap_3_10) {
            if (next_10_4 < dp_3_10) {
                dp_3_10 = next_10_4;
                dir_3_10 = dir_4_10;
            }
        }
        double next_10_6 = dp_6_10 + rubble_6_10;
        if (onTheMap_7_10) {
            if (next_10_6 < dp_7_10) {
                dp_7_10 = next_10_6;
                dir_7_10 = dir_6_10;
            }
        }
        double next_6_10 = dp_10_6 + rubble_10_6;
        if (onTheMap_10_7) {
            if (next_6_10 < dp_10_7) {
                dp_10_7 = next_6_10;
                dir_10_7 = dir_10_6;
            }
        }
        double next_4_10 = dp_10_4 + rubble_10_4;
        if (onTheMap_10_3) {
            if (next_4_10 < dp_10_3) {
                dp_10_3 = next_4_10;
                dir_10_3 = dir_10_4;
            }
        }
        double next_0_6 = dp_6_0 + rubble_6_0;
        if (onTheMap_7_0) {
            if (next_0_6 < dp_7_0) {
                dp_7_0 = next_0_6;
                dir_7_0 = dir_6_0;
            }
        }
        double next_0_3 = dp_3_0 + rubble_3_0;
        if (onTheMap_2_0) {
            if (next_0_3 < dp_2_0) {
                dp_2_0 = next_0_3;
                dir_2_0 = dir_3_0;
            }
        }
        double next_3_0 = dp_0_3 + rubble_0_3;
        if (onTheMap_0_2) {
            if (next_3_0 < dp_0_2) {
                dp_0_2 = next_3_0;
                dir_0_2 = dir_0_3;
            }
        }
        double next_7_0 = dp_0_7 + rubble_0_7;
        if (onTheMap_0_8) {
            if (next_7_0 < dp_0_8) {
                dp_0_8 = next_7_0;
                dir_0_8 = dir_0_7;
            }
        }
        double next_10_3 = dp_3_10 + rubble_3_10;
        if (onTheMap_2_10) {
            if (next_10_3 < dp_2_10) {
                dp_2_10 = next_10_3;
                dir_2_10 = dir_3_10;
            }
        }
        double next_10_7 = dp_7_10 + rubble_7_10;
        if (onTheMap_8_10) {
            if (next_10_7 < dp_8_10) {
                dp_8_10 = next_10_7;
                dir_8_10 = dir_7_10;
            }
        }
        double next_7_10 = dp_10_7 + rubble_10_7;
        if (onTheMap_10_8) {
            if (next_7_10 < dp_10_8) {
                dp_10_8 = next_7_10;
                dir_10_8 = dir_10_7;
            }
        }
        double next_3_10 = dp_10_3 + rubble_10_3;
        if (onTheMap_10_2) {
            if (next_3_10 < dp_10_2) {
                dp_10_2 = next_3_10;
                dir_10_2 = dir_10_3;
            }
        }
        double next_0_7 = dp_7_0 + rubble_7_0;
        if (onTheMap_8_0) {
            if (next_0_7 < dp_8_0) {
                dp_8_0 = next_0_7;
                dir_8_0 = dir_7_0;
            }
        }
        double next_1_1 = dp_1_1 + rubble_1_1;
        if (onTheMap_2_0) {
            if (next_1_1 < dp_2_0) {
                dp_2_0 = next_1_1;
                dir_2_0 = dir_1_1;
            }
        }
        if (onTheMap_0_2) {
            if (next_1_1 < dp_0_2) {
                dp_0_2 = next_1_1;
                dir_0_2 = dir_1_1;
            }
        }
        double next_9_1 = dp_1_9 + rubble_1_9;
        if (onTheMap_2_10) {
            if (next_9_1 < dp_2_10) {
                dp_2_10 = next_9_1;
                dir_2_10 = dir_1_9;
            }
        }
        if (onTheMap_0_8) {
            if (next_9_1 < dp_0_8) {
                dp_0_8 = next_9_1;
                dir_0_8 = dir_1_9;
            }
        }
        double next_9_9 = dp_9_9 + rubble_9_9;
        if (onTheMap_10_8) {
            if (next_9_9 < dp_10_8) {
                dp_10_8 = next_9_9;
                dir_10_8 = dir_9_9;
            }
        }
        if (onTheMap_8_10) {
            if (next_9_9 < dp_8_10) {
                dp_8_10 = next_9_9;
                dir_8_10 = dir_9_9;
            }
        }
        double next_1_9 = dp_9_1 + rubble_9_1;
        if (onTheMap_10_2) {
            if (next_1_9 < dp_10_2) {
                dp_10_2 = next_1_9;
                dir_10_2 = dir_9_1;
            }
        }
        if (onTheMap_8_0) {
            if (next_1_9 < dp_8_0) {
                dp_8_0 = next_1_9;
                dir_8_0 = dir_9_1;
            }
        }
        switch (target.x - ourLocationX) {
            case -5:
                switch (target.y - ourLocationY) {
                    case -3:
                        return dir_2_0;
                    case -2:
                        return dir_3_0;
                    case -1:
                        return dir_4_0;
                    case 0:
                        return dir_5_0;
                    case 1:
                        return dir_6_0;
                    case 2:
                        return dir_7_0;
                    case 3:
                        return dir_8_0;
                }
                break;
            case -4:
                switch (target.y - ourLocationY) {
                    case -4:
                        return dir_1_1;
                    case -3:
                        return dir_2_1;
                    case -2:
                        return dir_3_1;
                    case -1:
                        return dir_4_1;
                    case 0:
                        return dir_5_1;
                    case 1:
                        return dir_6_1;
                    case 2:
                        return dir_7_1;
                    case 3:
                        return dir_8_1;
                    case 4:
                        return dir_9_1;
                }
                break;
            case -3:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_2;
                    case -4:
                        return dir_1_2;
                    case -3:
                        return dir_2_2;
                    case -2:
                        return dir_3_2;
                    case -1:
                        return dir_4_2;
                    case 0:
                        return dir_5_2;
                    case 1:
                        return dir_6_2;
                    case 2:
                        return dir_7_2;
                    case 3:
                        return dir_8_2;
                    case 4:
                        return dir_9_2;
                    case 5:
                        return dir_10_2;
                }
                break;
            case -2:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_3;
                    case -4:
                        return dir_1_3;
                    case -3:
                        return dir_2_3;
                    case -2:
                        return dir_3_3;
                    case -1:
                        return dir_4_3;
                    case 0:
                        return dir_5_3;
                    case 1:
                        return dir_6_3;
                    case 2:
                        return dir_7_3;
                    case 3:
                        return dir_8_3;
                    case 4:
                        return dir_9_3;
                    case 5:
                        return dir_10_3;
                }
                break;
            case -1:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_4;
                    case -4:
                        return dir_1_4;
                    case -3:
                        return dir_2_4;
                    case -2:
                        return dir_3_4;
                    case -1:
                        return dir_4_4;
                    case 0:
                        return dir_5_4;
                    case 1:
                        return dir_6_4;
                    case 2:
                        return dir_7_4;
                    case 3:
                        return dir_8_4;
                    case 4:
                        return dir_9_4;
                    case 5:
                        return dir_10_4;
                }
                break;
            case 0:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_5;
                    case -4:
                        return dir_1_5;
                    case -3:
                        return dir_2_5;
                    case -2:
                        return dir_3_5;
                    case -1:
                        return dir_4_5;
                    case 0:
                        return dir_5_5;
                    case 1:
                        return dir_6_5;
                    case 2:
                        return dir_7_5;
                    case 3:
                        return dir_8_5;
                    case 4:
                        return dir_9_5;
                    case 5:
                        return dir_10_5;
                }
                break;
            case 1:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_6;
                    case -4:
                        return dir_1_6;
                    case -3:
                        return dir_2_6;
                    case -2:
                        return dir_3_6;
                    case -1:
                        return dir_4_6;
                    case 0:
                        return dir_5_6;
                    case 1:
                        return dir_6_6;
                    case 2:
                        return dir_7_6;
                    case 3:
                        return dir_8_6;
                    case 4:
                        return dir_9_6;
                    case 5:
                        return dir_10_6;
                }
                break;
            case 2:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_7;
                    case -4:
                        return dir_1_7;
                    case -3:
                        return dir_2_7;
                    case -2:
                        return dir_3_7;
                    case -1:
                        return dir_4_7;
                    case 0:
                        return dir_5_7;
                    case 1:
                        return dir_6_7;
                    case 2:
                        return dir_7_7;
                    case 3:
                        return dir_8_7;
                    case 4:
                        return dir_9_7;
                    case 5:
                        return dir_10_7;
                }
                break;
            case 3:
                switch (target.y - ourLocationY) {
                    case -5:
                        return dir_0_8;
                    case -4:
                        return dir_1_8;
                    case -3:
                        return dir_2_8;
                    case -2:
                        return dir_3_8;
                    case -1:
                        return dir_4_8;
                    case 0:
                        return dir_5_8;
                    case 1:
                        return dir_6_8;
                    case 2:
                        return dir_7_8;
                    case 3:
                        return dir_8_8;
                    case 4:
                        return dir_9_8;
                    case 5:
                        return dir_10_8;
                }
                break;
            case 4:
                switch (target.y - ourLocationY) {
                    case -4:
                        return dir_1_9;
                    case -3:
                        return dir_2_9;
                    case -2:
                        return dir_3_9;
                    case -1:
                        return dir_4_9;
                    case 0:
                        return dir_5_9;
                    case 1:
                        return dir_6_9;
                    case 2:
                        return dir_7_9;
                    case 3:
                        return dir_8_9;
                    case 4:
                        return dir_9_9;
                }
                break;
            case 5:
                switch (target.y - ourLocationY) {
                    case -3:
                        return dir_2_10;
                    case -2:
                        return dir_3_10;
                    case -1:
                        return dir_4_10;
                    case 0:
                        return dir_5_10;
                    case 1:
                        return dir_6_10;
                    case 2:
                        return dir_7_10;
                    case 3:
                        return dir_8_10;
                }
                break;
        }
        Direction bestDir = null;
        double bestScore = Double.MAX_VALUE;
        if (onTheMap_4_0) {
            double score = dp_4_0 + rubble_4_0 + Math.sqrt(loc_4_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_4_0;
            }
        }
        if (onTheMap_3_0) {
            double score = dp_3_0 + rubble_3_0 + Math.sqrt(loc_3_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_3_0;
            }
        }
        if (onTheMap_2_0) {
            double score = dp_2_0 + rubble_2_0 + Math.sqrt(loc_2_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_2_0;
            }
        }
        if (onTheMap_2_1) {
            double score = dp_2_1 + rubble_2_1 + Math.sqrt(loc_2_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_2_1;
            }
        }
        if (onTheMap_1_1) {
            double score = dp_1_1 + rubble_1_1 + Math.sqrt(loc_1_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_1;
            }
        }
        if (onTheMap_1_2) {
            double score = dp_1_2 + rubble_1_2 + Math.sqrt(loc_1_2.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_2;
            }
        }
        if (onTheMap_0_2) {
            double score = dp_0_2 + rubble_0_2 + Math.sqrt(loc_0_2.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_2;
            }
        }
        if (onTheMap_0_3) {
            double score = dp_0_3 + rubble_0_3 + Math.sqrt(loc_0_3.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_3;
            }
        }
        if (onTheMap_0_4) {
            double score = dp_0_4 + rubble_0_4 + Math.sqrt(loc_0_4.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_4;
            }
        }
        if (onTheMap_0_5) {
            double score = dp_0_5 + rubble_0_5 + Math.sqrt(loc_0_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_5;
            }
        }
        if (onTheMap_0_6) {
            double score = dp_0_6 + rubble_0_6 + Math.sqrt(loc_0_6.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_6;
            }
        }
        if (onTheMap_0_7) {
            double score = dp_0_7 + rubble_0_7 + Math.sqrt(loc_0_7.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_7;
            }
        }
        if (onTheMap_0_8) {
            double score = dp_0_8 + rubble_0_8 + Math.sqrt(loc_0_8.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_0_8;
            }
        }
        if (onTheMap_1_8) {
            double score = dp_1_8 + rubble_1_8 + Math.sqrt(loc_1_8.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_8;
            }
        }
        if (onTheMap_1_9) {
            double score = dp_1_9 + rubble_1_9 + Math.sqrt(loc_1_9.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_1_9;
            }
        }
        if (onTheMap_2_9) {
            double score = dp_2_9 + rubble_2_9 + Math.sqrt(loc_2_9.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_2_9;
            }
        }
        if (onTheMap_2_10) {
            double score = dp_2_10 + rubble_2_10 + Math.sqrt(loc_2_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_2_10;
            }
        }
        if (onTheMap_3_10) {
            double score = dp_3_10 + rubble_3_10 + Math.sqrt(loc_3_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_3_10;
            }
        }
        if (onTheMap_4_10) {
            double score = dp_4_10 + rubble_4_10 + Math.sqrt(loc_4_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_4_10;
            }
        }
        if (onTheMap_5_10) {
            double score = dp_5_10 + rubble_5_10 + Math.sqrt(loc_5_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_5_10;
            }
        }
        if (onTheMap_6_10) {
            double score = dp_6_10 + rubble_6_10 + Math.sqrt(loc_6_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_6_10;
            }
        }
        if (onTheMap_7_10) {
            double score = dp_7_10 + rubble_7_10 + Math.sqrt(loc_7_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_7_10;
            }
        }
        if (onTheMap_8_10) {
            double score = dp_8_10 + rubble_8_10 + Math.sqrt(loc_8_10.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_8_10;
            }
        }
        if (onTheMap_8_9) {
            double score = dp_8_9 + rubble_8_9 + Math.sqrt(loc_8_9.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_8_9;
            }
        }
        if (onTheMap_9_9) {
            double score = dp_9_9 + rubble_9_9 + Math.sqrt(loc_9_9.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_9_9;
            }
        }
        if (onTheMap_9_8) {
            double score = dp_9_8 + rubble_9_8 + Math.sqrt(loc_9_8.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_9_8;
            }
        }
        if (onTheMap_10_8) {
            double score = dp_10_8 + rubble_10_8 + Math.sqrt(loc_10_8.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_8;
            }
        }
        if (onTheMap_10_7) {
            double score = dp_10_7 + rubble_10_7 + Math.sqrt(loc_10_7.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_7;
            }
        }
        if (onTheMap_10_6) {
            double score = dp_10_6 + rubble_10_6 + Math.sqrt(loc_10_6.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_6;
            }
        }
        if (onTheMap_10_5) {
            double score = dp_10_5 + rubble_10_5 + Math.sqrt(loc_10_5.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_5;
            }
        }
        if (onTheMap_10_4) {
            double score = dp_10_4 + rubble_10_4 + Math.sqrt(loc_10_4.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_4;
            }
        }
        if (onTheMap_10_3) {
            double score = dp_10_3 + rubble_10_3 + Math.sqrt(loc_10_3.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_3;
            }
        }
        if (onTheMap_10_2) {
            double score = dp_10_2 + rubble_10_2 + Math.sqrt(loc_10_2.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_10_2;
            }
        }
        if (onTheMap_9_2) {
            double score = dp_9_2 + rubble_9_2 + Math.sqrt(loc_9_2.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_9_2;
            }
        }
        if (onTheMap_9_1) {
            double score = dp_9_1 + rubble_9_1 + Math.sqrt(loc_9_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_9_1;
            }
        }
        if (onTheMap_8_1) {
            double score = dp_8_1 + rubble_8_1 + Math.sqrt(loc_8_1.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_8_1;
            }
        }
        if (onTheMap_8_0) {
            double score = dp_8_0 + rubble_8_0 + Math.sqrt(loc_8_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_8_0;
            }
        }
        if (onTheMap_7_0) {
            double score = dp_7_0 + rubble_7_0 + Math.sqrt(loc_7_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_7_0;
            }
        }
        if (onTheMap_6_0) {
            double score = dp_6_0 + rubble_6_0 + Math.sqrt(loc_6_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestScore = score;
                bestDir = dir_6_0;
            }
        }
        if (onTheMap_5_0) {
            double score = dp_5_0 + rubble_5_0 + Math.sqrt(loc_5_0.distanceSquaredTo(target)) * 8.0;
            if (score < bestScore) {
                bestDir = dir_5_0;
            }
        }
        return bestDir;
    }
}
